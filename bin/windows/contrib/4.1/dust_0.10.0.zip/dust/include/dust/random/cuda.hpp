#ifndef DUST_RANDOM_CUDA_HPP
#define DUST_RANDOM_CUDA_HPP

// Dust stuff, we'll want this again later
#ifndef HOST
#define HOST
#define HOSTDEVICE
#define DEVICE
#define SYNCWARP
#define CONSTANT
#define __nv_exec_check_disable__
#endif

#endif
