library(testthat)
library(pika)

test_check("pika")
