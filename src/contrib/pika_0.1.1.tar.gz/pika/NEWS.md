# pika 0.1.1

* Added a `NEWS.md` file to track changes to the package.
* Added `calc_percent_change()` to calculate the percent change in a time series relative to a baseline period
