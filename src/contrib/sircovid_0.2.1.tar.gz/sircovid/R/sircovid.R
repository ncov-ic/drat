##' Create a model
##' @title Create a model
##' @export
##' @param params List of parameters of the model
sircovid <- function(params) {
  basic(user = params)
}
