# odin.dust 0.1.0

* Add support for odin-like `coef()`, which returns information about `user` parameters (#32)
