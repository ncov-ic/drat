png("graph.png")
par(mar = c(4, 4, 4, .5))
barplot(nmin, main = disease)
dev.off()
