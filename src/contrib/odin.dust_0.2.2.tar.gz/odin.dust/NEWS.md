# odin.dust 0.2.1

* `data_t` declarations can use `real_t` rather than `double` (#57)

# odin.dust 0.2.0

* GPU support (#66)

# odin.dust 0.1.15

* Start implementing dust gpu support by generating interleaved update function, optionally (#37)

# odin.dust 0.1.11

* Support for dust `compare` functions (#51)

# odin.dust 0.1.10

* Implement modulo (`%%`) operator, which uses `std::fmod`

# odin.dust 0.1.8

* Correct age-structured model in package vignette

# odin.dust 0.1.7

* Separate internal data into mutable and non-mutable components (#45)

# odin.dust 0.1.6

* Support for vectors of floats (rather than doubles) (#6)

# odin.dust 0.1.5

* Support `as.integer()` in odin code (since odin 1.0.7) (#43)

# odin.dust 0.1.4

* Add support for `config(include) <- file.cpp` for including custom C++ code to extend the library support (#39)

# odin.dust 0.1.0

* Add support for odin-like `coef()`, which returns information about `user` parameters (#32)
