# mode

<!-- badges: start -->
[![Project Status: Concept – Minimal or no implementation has been done yet, or the repository is only intended to be a limited example, demo, or proof-of-concept.](https://www.repostatus.org/badges/latest/concept.svg)](https://www.repostatus.org/#concept)
[![R build status](https://github.com/mrc-ide/mode/workflows/R-CMD-check/badge.svg)](https://github.com/mrc-ide/mode/actions)
[![codecov.io](https://codecov.io/github/mrc-ide/mode/coverage.svg?branch=main)](https://codecov.io/github/mrc-ide/mode?branch=main)
<!-- badges: end -->

## Installation

To install `mode`:

```r
remotes::install_github("mrc-ide/mode", upgrade = FALSE)
```

## License

MIT © Imperial College of Science, Technology and Medicine
