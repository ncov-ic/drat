# orderly: draft

This directory contains the result of running your reports.  Do not edit anything inside this directory.  These are *draft* reports and should be considered temporary.  You can *commit* a draft report to move it into `archive` and to add it to the database.

(you can delete or edit this file safely)
