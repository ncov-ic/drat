void mult_mv(int n, const double *m, const double *v, double *out);
double norm2(int n, const double *x);
double dot(int n, const double *a, const double *b);
