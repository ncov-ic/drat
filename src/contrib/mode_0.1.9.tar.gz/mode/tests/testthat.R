library(testthat)
library(mode)

test_check("mode")
