{{header}}
#ifndef DUST_RANDOM_VERSION_HPP
#define DUST_RANDOM_VERSION_HPP

#define DUST_VERSION_MAJOR {{major}}
#define DUST_VERSION_MINOR {{minor}}
#define DUST_VERSION_PATCH {{patch}}
#define DUST_VERSION_STRING "{{string}}"
#define DUST_VERSION_CODE {{code}}

#endif
