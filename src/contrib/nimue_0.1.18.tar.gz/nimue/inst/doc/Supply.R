## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo = TRUE, results = "hide", warning = FALSE, message = FALSE---------
library(nimue)
library(ggplot2)
library(dplyr)

## ---- echo = TRUE-------------------------------------------------------------
# Run the with no vaccine supply constraint
constant <- run(
  country = "United Kingdom",
  max_vaccine = 100000,
  vaccine_efficacy_disease = rep(0, 17),
  vaccine_efficacy_infection = rep(0.9, 17)
)
# Format the output selecting vaccines and deaths
o1 <- format(constant, compartments = NULL, summaries = c("deaths", "vaccines")) %>%
  mutate(Name = "Constant")


## ---- echo = TRUE-------------------------------------------------------------
# Run with initial vaccine supply constraints
increasing <- run(
  country = "United Kingdom",
  max_vaccine = seq(0, 100000, length.out = 100),
  tt_vaccine = seq(0, 100, length.out = 100),
  vaccine_efficacy_disease = rep(0, 17),
  vaccine_efficacy_infection = rep(0.9, 17)
)
# Format the output selecting vaccines and deaths
o2 <- format(increasing, compartments = NULL, summaries = c("deaths", "vaccines")) %>%
  mutate(Name = "Increasing")


## ---- echo = TRUE, fig.width = 7, fig.height = 3, fig.align = "center", warning = FALSE----
# Create plot data.frame
pd <- bind_rows(o1, o2)
# Plot outputs
ggplot(pd, aes(x = t, y = value, col = Name)) +
  geom_line(size = 1) +
  facet_wrap(~ compartment, scales = "free_y") +
  ylab("Time") +
  theme_bw()

