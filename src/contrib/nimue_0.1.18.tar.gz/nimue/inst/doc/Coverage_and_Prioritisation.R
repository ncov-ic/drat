## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ---- echo = TRUE, results = "hide", warning = FALSE, message = FALSE---------
library(nimue)
library(ggplot2)
library(dplyr)

## ---- fig.width = 7, fig.height = 5, fig.align = "center"---------------------
# Parameterise a strategy matrix
elderly <- strategy_matrix(strategy = "Elderly",
                           max_coverage = 0.8)

# Visualise
plot_matrix <- function(mat){
  age_labels <- c(paste0(seq(0, 75, 5), "-", seq(5, 80, 5)), "80+")
  colnames(mat) <- age_labels
  rownames(mat) <- 1:nrow(mat)
  pd <- as.data.frame.table(mat)
  colnames(pd) <- c("Prioritisation step", "Age group", "Coverage")
  ggplot(pd, aes(y = `Prioritisation step`, x = `Age group`, fill = Coverage)) +
    geom_tile() +
    theme_bw() +
    theme(axis.text.x=element_text(angle = -90, vjust = 0.3))
}

plot_matrix(elderly)

## ---- fig.width = 7, fig.height = 5, fig.align = "center"---------------------
# Parameterise a strategy matrix
at_risk <- strategy_matrix(strategy = "Risk Elderly Working Children step",
                           max_coverage = 0.8,
                           risk_proportion = 0.1)

# Visualise
plot_matrix(at_risk)

