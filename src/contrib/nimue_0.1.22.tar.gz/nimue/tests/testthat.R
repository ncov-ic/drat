library(testthat)
library(nimue)

test_check("nimue")
