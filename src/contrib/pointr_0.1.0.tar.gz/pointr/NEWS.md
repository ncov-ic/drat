# pointr 0.0.4

* Added a `NEWS.md` file to track changes to the package.
* In `sharepoint_download()` the default tempfile for `save_path` inherits the 
  file extension from `sharepoint_path`.
* Add a default tempfile for `save_path` argument of `pointr$download()`.
  
