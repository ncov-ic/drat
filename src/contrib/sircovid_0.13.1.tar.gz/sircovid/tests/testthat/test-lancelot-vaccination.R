context("lancelot (vaccination)")


test_that("No infections with perfect vaccine wrt rel_susceptibility", {
  ## i.e. if everyone is vaccinated with a vaccine preventing
  ## 100% of acquisition

  ## waning_rate default is 0, setting to a non-zero value so that this test
  ## passes with waning immunity
  p <- lancelot_parameters(0, "england", rel_susceptibility = c(1, 0),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           waning_rate = 1 / 20)
  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  index_S <- array(info$index$S, info$dim$S)
  state[index_S[, 2]] <- state[index_S[, 1]]
  state[index_S[, 1]] <- 0

  mod$update_state(state = state)
  mod$set_index(info$index$S)
  s <- mod$simulate(seq(0, 400, by = 4))

  ## Reshape to show the full shape of s
  expect_equal(length(s), prod(info$dim$S) * 101)
  s <- array(s, c(info$dim$S, 101))

  ## Noone moves into unvaccinated
  ## except in the group where infections because of waning immunity
  expect_true(all(s[-4, 1, ] == 0))

  ## Noone changes compartment within the vaccinated individuals
  expect_true(all(s[, 2, ] == s[, 2, 1]))
})


test_that("No symptomatic infections with perfect vaccine wrt rel_p_sympt", {
  ## i.e. if everyone is vaccinated with a vaccine preventing
  ## 100% of symptoms

  ## waning_rate default is 0, setting to a non-zero value so that this test
  ## passes with waning immunity
  p <- lancelot_parameters(0, "england",
                           rel_susceptibility = c(1, 1),
                           rel_p_sympt = c(1, 0),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           waning_rate = 1 / 20)
  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  index_S <- array(info$index$S, info$dim$S)
  state[index_S[, 2]] <- state[index_S[, 1]]
  state[index_S[, 1]] <- 0

  mod$update_state(state = state)
  y <- mod$transform_variables(drop(mod$simulate(seq(0, 400, by = 4))))

  ## Noone moves into I_P, I_C_1 or I_C_2 ever
  ## other than in the 4th age group where some infections are seeded
  ## in the unvaccinated group and because of waning immunity they may
  ## eventually end up in I_P and I_C_2 upon reinfection
  expect_true(all(y$I_P[-4, , , , ] == 0))
  expect_true(all(y$I_C_1[-4, , , , ] == 0))
  expect_true(all(y$I_C_2[-4, , , , ] == 0))

})


test_that("Noone hospitalised with perfect vaccine wrt rel_p_hosp_if_sympt", {
  ## i.e. if everyone is vaccinated with a vaccine preventing
  ## 100% of hospitalisations

  ## waning_rate default is 0, setting to a non-zero value so that this test
  ## passes with waning immunity
  p <- lancelot_parameters(0, "england",
                           rel_susceptibility = c(1, 1),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 0),
                           rel_p_death = c(1, 1),
                           waning_rate = 1 / 20)
  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  index_S <- array(info$index$S, info$dim$S)
  state[index_S[, 2]] <- state[index_S[, 1]]
  state[index_S[, 1]] <- 0

  mod$update_state(state = state)
  y <- mod$transform_variables(drop(mod$simulate(seq(0, 400, by = 4))))

  ## Noone moves into hospitalised compartments ever
  ## other than in the 4th age group where some infections are seeded
  ## in the unvaccinated group and because of waning immunity they may
  ## eventually end up in hospital upon reinfection
  expect_true(all(y$D_hosp[-4, ] == 0))
  expect_true(all(y$H_R_unconf[-4, , , , ] == 0))
  expect_true(all(y$H_R_conf[-4, , , , ] == 0))
  expect_true(all(y$H_D_unconf[-4, , , , ] == 0))
  expect_true(all(y$H_D_conf[-4, , , , ] == 0))
})


test_that("No infections with perfect vaccine wrt rel_infectivity", {
  ## i.e. if everyone is vaccinated with a vaccine preventing
  ## 100% of onwards transmission

  ## waning_rate default is 0, setting to a non-zero value so that this test
  ## passes with waning immunity
  p <- lancelot_parameters(0, "england", rel_infectivity = c(1, 0),
                           waning_rate = 1 / 20)
  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  # move susceptibles into vaccinated class
  index_S <- array(info$index$S, info$dim$S)
  state[index_S[, 2]] <- state[index_S[, 1]]
  state[index_S[, 1]] <- 0

  # move initial infections into vaccinated class
  index_I_A <- array(info$index$I_A, info$dim$I_A)
  state[index_I_A[, 1, 1, 2]] <- state[index_I_A[, 1, 1, 1]]
  state[index_I_A[, 1, 1, 1]] <- 0

  mod$update_state(state = state)
  mod$set_index(info$index$S)
  s <- mod$simulate(seq(0, 400, by = 4))

  ## Reshape to show the full shape of s
  expect_equal(length(s), prod(info$dim$S) * 101)
  s <- array(s, c(info$dim$S, 101))

  ## Noone moves into unvaccinated
  ## except in the group where infections because of waning immunity
  expect_true(all(s[-4, 1, ] == 0))

  ## Noone changes compartment within the vaccinated individuals
  ## except in the group where infections because of waning immunity
  expect_true(all(s[-4, 2, ] == s[-4, 2, 1]))

})

test_that("No deaths with perfect vaccine wrt rel_p_death", {
  ## i.e. if everyone is vaccinated with a vaccine preventing
  ## 100% of deaths

  p <- lancelot_parameters(0, "england",
                           rel_susceptibility = c(1, 1),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 0),
                           waning_rate = 1 / 20)
  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  index_S <- array(info$index$S, info$dim$S)
  state[index_S[, 2]] <- state[index_S[, 1]]
  state[index_S[, 1]] <- 0

  mod$update_state(state = state)
  y <- mod$transform_variables(drop(mod$simulate(seq(0, 400, by = 4))))

  ## No-one moves into D compartments ever
  expect_true(all(y$H_D_unconf == 0))
  expect_true(all(y$H_D_conf == 0))
  expect_true(all(y$ICU_D_unconf == 0))
  expect_true(all(y$ICU_D_conf == 0))
  expect_true(all(y$W_D_unconf == 0))
  expect_true(all(y$W_D_conf == 0))
  expect_true(all(y$G_D == 0))
  expect_true(all(y$D_hosp == 0))
  expect_true(all(y$D_non_hosp == 0))
  expect_true(all(y$D == 0))
  expect_true(all(y$D_hosp_tot == 0))
  expect_true(all(y$D_comm_tot == 0))
  expect_true(all(y$D_lancelot_tot == 0))
  expect_true(all(y$D_tot == 0))
})


test_that("Vaccination of susceptibles works", {
  ## Tests that:
  ## Every susceptible moves to vaccinated and stays there if
  ## everyone quickly gets vaccinated with a vaccine preventing 100% of
  ## acquisition and no waning immunity
  region <- "london"
  vaccine_schedule <- test_vaccine_schedule(daily_doses = Inf,
                                            region = region,
                                            mean_days_between_doses = 1000,
                                            uptake = 1)
  p <- lancelot_parameters(0, region, beta_value = c(0, 0, 1),
                           beta_date = c(0, 4, 5),
                           rel_susceptibility = c(1, 0),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L)

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()
  mod$update_state(state = lancelot_initial(info, 1, p))
  y <- mod$transform_variables(drop(mod$simulate(seq(0, 400, by = 4))))
  i <- 4:lancelot_n_groups()

  ## Predefined schedule means we may end up not vaccinating exactly everyone
  ## hence the approximate comparison
  expect_true(all(abs(y$S[i, 1, 1] - y$S[i, 2, 2]) / y$S[i, 1, 1] < 0.01))
  expect_equal(y$S[i, , 101], y$S[i, , 2])
})


test_that("Vaccination of exposed individuals works", {
  ## Tests that:
  ## Every exposed moves to vaccinated and stays there if everyone
  ## quickly gets vaccinated with a vaccine with no waning immunity
  ## and if disease progression is stopped after E
  region <- "london"
  vaccine_schedule <- test_vaccine_schedule(daily_doses = Inf,
                                            region = region,
                                            mean_days_between_doses = 1000,
                                            uptake = 1)
  p <- lancelot_parameters(0, region,
                           rel_susceptibility = c(1, 0),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L)

  # stop disease progression after E
  p$gamma_E_step <- 0

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  index_E <- array(info$index$E, info$dim$E)
  index_S <- array(info$index$S, info$dim$S)
  state[index_E[, , 1, ]] <- round(state[index_S] / 2)
  state[index_E[, , 2, ]] <- round(state[index_S] / 2)
  state[index_S] <- 0

  mod$update_state(state = state)
  mod$set_index(info$index$E)
  e <- mod$simulate(seq(0, 400, by = 4))

  ## Reshape to show the full shape of e
  expect_equal(length(e), prod(info$dim$E) * 101)
  e <- array(e, c(info$dim$E, 101))

  ## every E moves from unvaccinated to vaccinated between
  ## time steps 1 and 2
  E_compartment_idx <- 1
  unvacc_idx <- 1
  vacc_idx <- 2
  i <- 4:lancelot_n_groups()

  expect_approx_equal(e[i, , E_compartment_idx, unvacc_idx, 1],
                      e[i, , E_compartment_idx, vacc_idx, 2])
  ## then they don't move anymore
  expect_equal(e[i, , E_compartment_idx, vacc_idx, 2],
               e[i, , E_compartment_idx, vacc_idx, 101])
  ## same for second E compartment
  E_compartment_idx <- 2
  expect_approx_equal(e[i, , E_compartment_idx, unvacc_idx, 1],
                      e[i, , E_compartment_idx, vacc_idx, 2])
  ## then they don't move anymore
  expect_approx_equal(e[i, , E_compartment_idx, vacc_idx, 2],
                      e[i, , E_compartment_idx, vacc_idx, 101])
})


test_that("Vaccination of asymptomatic infectious individuals works", {
  ## Tests that:
  ## Every I_A moves to vaccinated and stays there if everyone
  ## quickly gets vaccinated with a vaccine with no waning immunity
  ## and if disease progression is stopped after I_A
  region <- "london"
  vaccine_schedule <- test_vaccine_schedule(daily_doses = Inf,
                                            region = region,
                                            mean_days_between_doses = 1000,
                                            uptake = 1)
  p <- lancelot_parameters(0, region,
                           rel_susceptibility = c(1, 0),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L)

  # stop disease progression after I_A
  p$gamma_A_step <- 0

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  index_I_A <- array(info$index$I_A, info$dim$I_A)
  index_S <- array(info$index$S, info$dim$S)
  state[index_I_A[, 1, 1, ]] <- state[index_S]
  state[index_S] <- 0

  mod$update_state(state = state)
  mod$set_index(info$index$I_A)
  i_A <- mod$simulate(seq(0, 400, by = 4))

  ## Reshape to show the full shape of i_A
  expect_equal(length(i_A), prod(info$dim$I_A) * 101)
  i_A <- array(i_A, c(info$dim$I_A, 101))

  ## every I_A moves from unvaccinated to vaccinated between
  ## time steps 1 and 2
  I_A_compartment_idx <- 1
  unvacc_idx <- 1
  vacc_idx <- 2
  i <- 4:lancelot_n_groups()
  expect_approx_equal(i_A[i, , I_A_compartment_idx, unvacc_idx, 1],
                      i_A[i, , I_A_compartment_idx, vacc_idx, 2])

  ## then they don't move anymore
  expect_equal(
    i_A[i, , I_A_compartment_idx, vacc_idx, 2],
    i_A[i, , I_A_compartment_idx, vacc_idx, 101])
})


test_that("Vaccination of presymptomatic infectious individuals works", {
  ## Tests that:
  ## Every I_P moves to vaccinated and stays there if everyone
  ## quickly gets vaccinated with a vaccine with no waning immunity
  ## and if disease progression is stopped after I_P
  region <- "london"
  vaccine_schedule <- test_vaccine_schedule(daily_doses = Inf,
                                            region = region,
                                            mean_days_between_doses = 1000,
                                            uptake = 1)
  p <- lancelot_parameters(0, region,
                           rel_susceptibility = c(1, 0),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L)

  # stop disease progression after I_P
  p$gamma_P_step <- 0

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  index_I_P <- array(info$index$I_P, info$dim$I_P)
  index_S <- array(info$index$S, info$dim$S)
  state[index_I_P[, 1, 1, ]] <- state[index_S]
  state[index_S] <- 0

  mod$update_state(state = state)
  mod$set_index(info$index$I_P)
  i_P <- mod$simulate(seq(0, 400, by = 4))

  ## Reshape to show the full shape of i_P
  expect_equal(length(i_P), prod(info$dim$I_P) * 101)
  i_P <- array(i_P, c(info$dim$I_P, 101))

  ## every I_P moves from unvaccinated to vaccinated between
  ## time steps 1 and 2
  I_P_compartment_idx <- 1
  unvacc_idx <- 1
  vacc_idx <- 2
  i <- 4:lancelot_n_groups()

  expect_approx_equal(i_P[i, , I_P_compartment_idx, unvacc_idx, 1],
                      i_P[i, , I_P_compartment_idx, vacc_idx, 2])

  ## then they don't move anymore
  expect_equal(
    i_P[i, , I_P_compartment_idx, vacc_idx, 2],
    i_P[i, , I_P_compartment_idx, vacc_idx, 101])
})


test_that("Vaccination of recovered individuals works", {
  ## Test that:
  ## Every R moves to vaccinated and stays there if everyone
  ## quickly gets vaccinated with a vaccine with no waning immunity
  ## and if no natural waning of immunity
  region <- "london"
  vaccine_schedule <- test_vaccine_schedule(daily_doses = Inf,
                                            region = region,
                                            mean_days_between_doses = 1000,
                                            uptake = 1)
  p <- lancelot_parameters(0, region,
                           rel_susceptibility = c(1, 0),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L)

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  index_I_A <- array(info$index$I_A, info$dim$I_A)
  index_R <- array(info$index$R, info$dim$R)
  index_S <- array(info$index$S, info$dim$S)
  state[index_R] <- state[index_S]
  state[index_S] <- 0
  state[index_I_A] <- 0 # remove seeded infections

  mod$update_state(state = state)
  mod$set_index(info$index$R)
  r <- mod$simulate(seq(0, 400, by = 4))

  ## Reshape to show the full shape of r
  expect_equal(length(r), prod(info$dim$R) * 101)
  r <- array(r, c(info$dim$R, 101))

  ## every R moves from unvaccinated to vaccinated between
  ## time steps 1 and 2
  unvacc_idx <- 1
  vacc_idx <- 2
  i <- 4:lancelot_n_groups()
  expect_approx_equal(r[i, , unvacc_idx, 1], r[i, , vacc_idx, 2])
  ## then they don't move anymore
  expect_equal(r[i, , vacc_idx, 2], r[i, , vacc_idx, 101])
})


test_that("Returning to unvaccinated stage works for exposed individuals", {
  ## Tests that:
  ## Every exposed moves back from vaccinated to unvaccinated and stays
  ## there if vaccine has fast waning immunity,
  ## beta is zero, and if disease progression
  ## is stopped after E
  p <- lancelot_parameters(0, "england",
                           beta_value = 0,
                           rel_susceptibility = c(1, 0),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           vaccine_progression_rate = c(0, Inf))

  # stop disease progression after E
  p$gamma_E_step <- 0

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  index_E <- array(info$index$E, info$dim$E)
  index_S <- array(info$index$S, info$dim$S)
  state[index_E[, 1, 1, 2]] <- state[index_S[, 1]]
  state[index_E[, 1, 1, 1]] <- 0
  state[index_E[, 1, 2, 2]] <- state[index_S[, 1]]
  state[index_E[, 1, 2, 1]] <- 0
  state[index_S] <- 0

  mod$update_state(state = state)
  mod$set_index(info$index$E)
  e <- mod$simulate(seq(0, 400, by = 4))

  ## Reshape to show the full shape of e
  expect_equal(length(e), prod(info$dim$E) * 101)
  e <- array(e, c(info$dim$E, 101))

  ## every E moves from vaccinated to unvaccinated between
  ## time steps 1 and 2
  E_compartment_idx <- 1
  unvacc_idx <- 1
  vacc_idx <- 2
  expect_equal(e[, 1, E_compartment_idx, vacc_idx, 1],
               e[, 1, E_compartment_idx, unvacc_idx, 2])
  ## then they don't move anymore
  expect_equal(e[, 1, E_compartment_idx, unvacc_idx, 2],
               e[, 1, E_compartment_idx, unvacc_idx, 101])
  ## same for second E compartment
  E_compartment_idx <- 2
  expect_equal(e[, 1, E_compartment_idx, vacc_idx, 1],
               e[, 1, E_compartment_idx, unvacc_idx, 2])
  ## then they don't move anymore
  expect_equal(e[, 1, E_compartment_idx, unvacc_idx, 2],
               e[, 1, E_compartment_idx, unvacc_idx, 101])
})


test_that("Returning to unvaccinated stage works for I_A individuals", {
  ## Tests that:
  ## Every I_A moves back from vaccinated to unvaccinated and stays
  ## there if vaccine has fast waning immunity,
  ## beta is zero, and if disease progression
  ## is stopped after I_A
  p <- lancelot_parameters(0, "england",
                           beta_value = 0,
                           rel_susceptibility = c(1, 0),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           vaccine_progression_rate = c(0, Inf))

  # stop disease progression after I_A
  p$gamma_A_step <- 0

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  index_I_A <- array(info$index$I_A, info$dim$I_A)
  index_S <- array(info$index$S, info$dim$S)
  state[index_I_A[, 1, 1, 2]] <- state[index_S[, 1]]
  state[index_I_A[, 1, 1, 1]] <- 0
  state[index_S] <- 0

  mod$update_state(state = state)
  mod$set_index(info$index$I_A)
  i_A <- mod$simulate(seq(0, 400, by = 4))

  ## Reshape to show the full shape of i_A
  expect_equal(length(i_A), prod(info$dim$I_A) * 101)
  i_A <- array(i_A, c(info$dim$I_A, 101))

  ## every I_A moves from vaccinated to unvaccinated between
  ## time steps 1 and 2
  I_A_compartment_idx <- 1
  unvacc_idx <- 1
  vacc_idx <- 2
  expect_equal(
    i_A[, 1, I_A_compartment_idx, vacc_idx, 1],
    i_A[, 1, I_A_compartment_idx, unvacc_idx, 2])
  ## then they don't move anymore
  expect_equal(
    i_A[, 1, I_A_compartment_idx, unvacc_idx, 2],
    i_A[, 1, I_A_compartment_idx, unvacc_idx, 101])
})


test_that("Returning to unvaccinated stage works for I_P individuals", {
  ## Tests that:
  ## Every I_P moves back from vaccinated to unvaccinated and stays
  ## there if vaccine has fast waning immunity,
  ## beta is zero, and if disease progression
  ## is stopped after I_P
  p <- lancelot_parameters(0, "england",
                           beta_value = 0,
                           rel_susceptibility = c(1, 0),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           vaccine_progression_rate = c(0, Inf))

  # stop disease progression after I_P
  p$gamma_P_step <- 0

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  index_I_P <- array(info$index$I_P, info$dim$I_P)
  index_S <- array(info$index$S, info$dim$S)
  state[index_I_P[, 1, 1, 2]] <- state[index_S[, 1]]
  state[index_I_P[, 1, 1, 1]] <- 0
  state[index_S] <- 0

  mod$update_state(state = state)
  mod$set_index(info$index$I_P)
  i_P <- mod$simulate(seq(0, 400, by = 4))

  ## Reshape to show the full shape of i_P
  expect_equal(length(i_P), prod(info$dim$I_P) * 101)
  i_P <- array(i_P, c(info$dim$I_P, 101))

  ## every I_P moves from vaccinated to unvaccinated between
  ## time steps 1 and 2
  I_P_compartment_idx <- 1
  unvacc_idx <- 1
  vacc_idx <- 2
  expect_equal(
    i_P[, 1, I_P_compartment_idx, vacc_idx, 1],
    i_P[, 1, I_P_compartment_idx, unvacc_idx, 2])
  ## then they don't move anymore
  expect_equal(
    i_P[, 1, I_P_compartment_idx, unvacc_idx, 2],
    i_P[, 1, I_P_compartment_idx, unvacc_idx, 101])
})


test_that("Returning to unvaccinated stage works for recovered individuals", {
  ## Tests that:
  ## Every R moves back from vaccinated to unvaccinated and stays
  ## there if vaccine has fast waning immunity,
  ## beta is zero, and there is no natural immunity
  p <- lancelot_parameters(0, "england",
                           beta_value = 0,
                           rel_susceptibility = c(1, 0),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           vaccine_progression_rate = c(0, Inf))

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  index_I_A <- array(info$index$I_A, info$dim$I_A)
  index_R <- array(info$index$R, info$dim$R)
  index_S <- array(info$index$S, info$dim$S)
  state[index_R[, 1, 2]] <- state[index_S[, 1]]
  state[index_R[, 1, 1]] <- 0
  state[index_S] <- 0
  state[index_I_A] <- 0 # remove seeded infections

  mod$update_state(state = state)
  mod$set_index(info$index$R)
  r <- mod$simulate(seq(0, 400, by = 4))

  ## Reshape to show the full shape of r
  expect_equal(length(r), prod(info$dim$R) * 101)
  r <- array(r, c(info$dim$R, 101))

  ## every R moves from vaccinated to unvaccinated between
  ## time steps 1 and 2
  unvacc_idx <- 1
  vacc_idx <- 2
  expect_equal(r[, 1, vacc_idx, 1], r[, 1, unvacc_idx, 2])
  ## then they don't move anymore
  expect_equal(r[, 1, unvacc_idx, 2], r[, 1, unvacc_idx, 101])
})


test_that("Vaccine progression through 3 classes works for susceptibles", {
  ## Tests that:
  ## Every susceptible moves to waning immunity stage and stays there if
  ## everyone quickly gets vaccinated and loses immunity
  region <- "london"
  vaccine_schedule <- test_vaccine_schedule(daily_doses = Inf,
                                            region = region,
                                            mean_days_between_doses = 1000,
                                            uptake = 1)
  p <- lancelot_parameters(0, region,
                           beta_value = 0,
                           rel_susceptibility = c(1, 0, 0),
                           rel_p_sympt = c(1, 1, 1),
                           rel_p_hosp_if_sympt = c(1, 1, 1),
                           rel_p_death = c(1, 1, 1),
                           vaccine_progression_rate = c(0, Inf, 0),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 3L)

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()
  mod$update_state(state = lancelot_initial(info, 1, p))
  i <- 4:lancelot_n_groups()
  y <- mod$transform_variables(drop(mod$simulate(seq(0, 400, by = 4))))
  expect_approx_equal(y$S[i, 1, 1], y$S[i, 3, 3])
  expect_equal(y$S[i, , 101], y$S[i, , 3])
})


test_that("Vaccine progression through 12 classes works for susceptibles", {
  ## Tests that:
  ## Every susceptible moves to last of 12 waning immunity stage and stays
  ## there if everyone quickly gets vaccinated and loses immunity
  region <- "london"
  vaccine_schedule <- test_vaccine_schedule(daily_doses = Inf,
                                            region = region,
                                            mean_days_between_doses = 1000,
                                            uptake = 1)
  p <- lancelot_parameters(0, region,
                           beta_value = 0,
                           rel_susceptibility = c(1, rep(0, 10), 0),
                           rel_p_sympt = rep(1, 12),
                           rel_p_hosp_if_sympt = rep(1, 12),
                           rel_p_death = rep(1, 12),
                           vaccine_progression_rate =
                             c(0, rep(Inf, 10), 0),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 12L)

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()
  mod$update_state(state = lancelot_initial(info, 1, p))
  y <- mod$transform_variables(drop(mod$simulate(seq(0, 400, by = 12))))
  i <- 4:lancelot_n_groups()
  expect_approx_equal(y$S[i, 1, 1], y$S[i, 12, 12])
  expect_equal(y$S[i, , 34], y$S[i, , 12])
})


test_that("Clinical progression within a vaccination class works", {
  for (i in 1:50) {
    ## Tests that:
    ## Every susceptible moves to the R compartment corresponding to their
    ## vaccination class if there is a high beta and no vaccine
    ## progression
    p <- lancelot_parameters(0, "england",
                             beta_value = 1e9,
                             rel_susceptibility = c(1, 1, 1),
                             rel_p_sympt = c(1, 1, 1),
                             rel_p_hosp_if_sympt = c(1, 1, 1),
                             rel_p_death = c(1, 1, 1),
                             vaccine_progression_rate =
                               c(0, 0, 0))

    # increase progression rates
    p[grep("^gamma", names(p))] <- 1e9
    # make p_death zero
    p[grep("^gamma\\S*_D_step", names(p))] <- 0
    p[grep("^p\\S*_D_step", names(p))] <- rep(list(array(0, c(1, p$n_groups))),
                                              length(grep("^p\\S*_D_step",
                                                          names(p))))
    p[grep("^n_p\\S*_D_step", names(p))] <- rep(list(1),
                                                length(grep("^n_p\\S*_D_step",
                                                            names(p))))

    mod <- lancelot$new(p, 0, 1, seed = 1L)
    info <- mod$info()

    state <- lancelot_initial(info, 1, p)

    index_S <- array(info$index$S, info$dim$S)
    index_R <- array(info$index$R, info$dim$R)
    index <- c(index_S, index_R)

    # split S individuals equally between all 3 vaccination groups
    state[index_S[, 2]] <- round(state[index_S[, 1]] / 3)
    state[index_S[, 3]] <- round(state[index_S[, 1]] / 3)
    state[index_S[, 1]] <- state[index_S[, 1]] - state[index_S[, 2]] -
      state[index_S[, 3]]

    mod$update_state(state = state)
    mod$set_index(index)
    y <- mod$simulate(seq(0, 400, by = 4))

    ## Reshape to show the full shape of s
    expect_equal(length(y),
                 prod(info$dim$S) * 101 + prod(info$dim$R) * 101)
    s <- array(y[seq_len(prod(info$dim$S)), , ], c(info$dim$S, 101))
    r <- array(y[prod(info$dim$S) + seq_len(prod(info$dim$R)), , ],
               c(info$dim$R, 101))

    ## all have moved from S to R in relevant vaccination class
    ## ignoring age group 4 where infections are seeded
    expect_approx_equal(s[-4, , 1], r[-4, 1, , 101])
  }
})


test_that("Returning to unvaccinated stage works for susceptibles", {
  ## Tests that:
  ## Every susceptible moves back to unvaccinated from vacinated if large
  ## waning of immunity and no vaccination
  p <- lancelot_parameters(0, "england",
                           beta_value = 0,
                           rel_susceptibility = c(1, 0),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           vaccine_progression_rate = c(0, Inf))

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  index_S <- array(info$index$S, info$dim$S)
  state[index_S[, 2]] <- state[index_S[, 1]]
  state[index_S[, 1]] <- 0

  mod$update_state(state = state)
  mod$set_index(info$index$S)
  s <- mod$simulate(seq(0, 400, by = 4))

  ## Reshape to show the full shape of s
  expect_equal(length(s), prod(info$dim$S) * 101)
  s <- array(s, c(info$dim$S, 101))

  ## noone left in vaccinated at time step 2
  expect_true(all(s[, 2, 2] == 0))

  ## everybody back in unvaccinated at time step 2
  expect_equal(s[, 1, 2], s[, 2, 1])
})


test_that("there are no vaccinated susceptibles when vaccination rate is 0", {
  ## waning_rate default is 0, setting to a non-zero value so that this test
  ## passes with waning immunity
  waning_rate <- rep(1 / 20, 19)
  waning_rate[4] <- 0 # no waning in group with seeded infections
  # otherwise S can go up as these infected individuals loose immunity

  p <- lancelot_parameters(0, "england",
                           waning_rate = waning_rate)
  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()
  mod$update_state(state = lancelot_initial(info, 1, p))
  mod$set_index(info$index$S)
  s <- mod$simulate(seq(0, 400, by = 4))

  ## No vaccinated susceptibles:
  expect_equal(s[-seq_len(lancelot_n_groups()), , ],
               array(0, c(nrow(s) - lancelot_n_groups(), 101)))
})


test_that("Can calculate Rt with an (empty) vaccination class", {
  ## run model with unvaccinated & vaccinated, but both have same susceptibility
  p <- lancelot_parameters(sircovid_date("2020-02-07"), "england",
                           rel_susceptibility = c(1, 1),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1))

  np <- 3L
  mod <- lancelot$new(p, 0, np, seed = 1L)

  initial <- lancelot_initial(mod$info(), 10, p)
  mod$update_state(state = initial)
  mod$set_index(integer(0))
  index <- mod$info()$index$S

  end <- sircovid_date("2020-05-01") / p$dt
  steps <- seq(0, end, by = 1 / p$dt)

  set.seed(1)
  mod$set_index(index)
  y <- mod$simulate(steps)

  rt_1 <- lancelot_Rt(steps, y[, 1, ], p)
  rt_all <- lancelot_Rt_trajectories(steps, y, p)

  ## run model with unvaccinated class only
  p <- lancelot_parameters(sircovid_date("2020-02-07"), "england",
                           rel_susceptibility = c(1, 1),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1))

  np <- 3L
  mod <- lancelot$new(p, 0, np, seed = 1L)

  initial <- lancelot_initial(mod$info(), 10, p)
  mod$update_state(state = initial)
  mod$set_index(integer(0))
  index <- mod$info()$index$S

  end <- sircovid_date("2020-05-01") / p$dt
  steps <- seq(0, end, by = 1 / p$dt)

  set.seed(1)
  mod$set_index(index)
  y <- mod$simulate(steps)

  rt_1_single_class <- lancelot_Rt(steps, y[, 1, ], p)
  rt_all_single_class <- lancelot_Rt_trajectories(steps, y, p)

  expect_equal(rt_1, rt_1_single_class)
  expect_equal(rt_all, rt_all_single_class)
})


test_that("Effective Rt reduced by rel_susceptibility if all vaccinated", {
  reduced_susceptibility <- 0.2 # can put anything <1 here

  ## run model with unvaccinated & vaccinated (with susceptibility halved)
  ## waning_rate default is 0, setting to a non-zero value so that this test
  ## passes with waning immunity
  p <- lancelot_parameters(sircovid_date("2020-02-07"), "england",
                           rel_susceptibility = c(1, reduced_susceptibility),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           waning_rate = 1 / 20)

  np <- 3L
  mod <- lancelot$new(p, 0, np, seed = 1L)

  initial <- lancelot_initial(mod$info(), 10, p)
  mod$update_state(state = initial)
  mod$set_index(integer(0))
  index <- mod$info()$index$S

  end <- sircovid_date("2020-05-01") / p$dt
  steps <- seq(0, end, by = 1 / p$dt)

  set.seed(1)
  mod$set_index(index)
  y <- mod$simulate(steps)

  rt_1 <- lancelot_Rt(steps, y[, 1, ], p)
  rt_all <- lancelot_Rt_trajectories(steps, y, p)

  ## move all individuals to vaccinated
  y_with_vacc <- y
  y_with_vacc[seq(p$n_groups + 1, 2 * p$n_groups), , ] <-
    y_with_vacc[seq_len(p$n_groups), , ]
  y_with_vacc[seq_len(p$n_groups), , ] <- 0

  rt_1_vacc <- lancelot_Rt(steps, y_with_vacc[, 1, ], p)
  rt_all_vacc <- lancelot_Rt_trajectories(steps, y_with_vacc, p)

  expect_equal(rt_1$eff_Rt_all * reduced_susceptibility,
               rt_1_vacc$eff_Rt_all)
  expect_equal(rt_1$eff_Rt_general * reduced_susceptibility,
               rt_1_vacc$eff_Rt_general)

  expect_equal(rt_all$eff_Rt_all * reduced_susceptibility,
               rt_all_vacc$eff_Rt_all)
  expect_equal(rt_all$eff_Rt_general * reduced_susceptibility,
               rt_all_vacc$eff_Rt_general)

})


test_that("Effective Rt reduced by rel_infectivity if all vaccinated", {
  reduced_infectivity <- 0.2 # can put anything <1 here

  ## run model with unvaccinated & vaccinated (with infectivity halved)
  ## waning_rate default is 0, setting to a non-zero value so that this test
  ## passes with waning immunity
  p <- lancelot_parameters(sircovid_date("2020-02-07"), "england",
                           rel_infectivity = c(1, reduced_infectivity),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           waning_rate = 1 / 20)

  np <- 3L
  mod <- lancelot$new(p, 0, np, seed = 1L)

  initial <- lancelot_initial(mod$info(), 10, p)
  mod$update_state(state = initial)
  mod$set_index(integer(0))
  index <- mod$info()$index$S

  end <- sircovid_date("2020-05-01") / p$dt
  steps <- seq(0, end, by = 1 / p$dt)

  set.seed(1)
  mod$set_index(index)
  y <- mod$simulate(steps)

  rt_1 <- lancelot_Rt(steps, y[, 1, ], p)
  rt_all <- lancelot_Rt_trajectories(steps, y, p)

  ## move all individuals to vaccinated
  y_with_vacc <- y
  y_with_vacc[seq(p$n_groups + 1, 2 * p$n_groups), , ] <-
    y_with_vacc[seq_len(p$n_groups), , ]
  y_with_vacc[seq_len(p$n_groups), , ] <- 0

  rt_1_vacc <- lancelot_Rt(steps, y_with_vacc[, 1, ], p)
  rt_all_vacc <- lancelot_Rt_trajectories(steps, y_with_vacc, p)

  expect_equal(rt_1$eff_Rt_all * reduced_infectivity,
               rt_1_vacc$eff_Rt_all)
  expect_equal(rt_1$eff_Rt_general * reduced_infectivity,
               rt_1_vacc$eff_Rt_general)

  expect_equal(rt_all$eff_Rt_all * reduced_infectivity,
               rt_all_vacc$eff_Rt_all)
  expect_equal(rt_all$eff_Rt_general * reduced_infectivity,
               rt_all_vacc$eff_Rt_general)

})


test_that("Effective Rt modified if rel_p_sympt is not 1", {
  reduced_p_C <- 0.2 # can put anything <1 here

  ## run model with unvaccinated & vaccinated (with susceptibility halved)
  ## waning_rate default is 0, setting to a non-zero value so that this test
  ## passes with waning immunity
  p <- lancelot_parameters(sircovid_date("2020-02-07"), "england",
                           rel_susceptibility = c(1, 1),
                           rel_p_sympt = c(1, reduced_p_C),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           waning_rate = 1 / 20)

  ## These are the same as the default values, but setting them again here in
  ## case defaults change as the below assumes mean duration is shorter for
  ## asymptomatic infections
  p$k_A <- 1
  p$gamma_A <- 1 / 2.88
  p$k_P <- 1
  p$gamma_P <- 1 / 1.68
  p$k_C_1 <- 1
  p$gamma_C_1 <- 1 / 2.14
  p$k_C_2 <- 1
  p$gamma_C_2 <- 1 / 1.86

  np <- 3L
  mod <- lancelot$new(p, 0, np, seed = 1L)

  initial <- lancelot_initial(mod$info(), 10, p)
  mod$update_state(state = initial)
  mod$set_index(integer(0))
  index <- mod$info()$index$S

  end <- sircovid_date("2020-05-01") / p$dt
  steps <- seq(0, end, by = 1 / p$dt)

  set.seed(1)
  mod$set_index(index)
  y <- mod$simulate(steps)

  rt_1 <- lancelot_Rt(steps, y[, 1, ], p)
  rt_all <- lancelot_Rt_trajectories(steps, y, p)

  ## move all individuals to vaccinated
  y_with_vacc <- y
  y_with_vacc[seq(p$n_groups + 1, 2 * p$n_groups), , ] <-
    y_with_vacc[seq_len(p$n_groups), , ]
  y_with_vacc[seq_len(p$n_groups), , ] <- 0

  rt_1_vacc <- lancelot_Rt(steps, y_with_vacc[, 1, ], p)
  rt_all_vacc <- lancelot_Rt_trajectories(steps, y_with_vacc, p)

  # check that the ratio between the Rt with and witout vaccination
  # is constant
  expect_true(all(abs(diff(rt_1_vacc$Rt_all / rt_1$Rt_all)) < 1e-7))

  ## Given mean duration is shorter for asymptomatic individuals, we expect
  ## Rt to be reduced when rel_p_sympt is not 1
  expect_true(all(rt_1_vacc$eff_Rt_all < rt_1$eff_Rt_all))
  expect_true(all(rt_1_vacc$eff_Rt_general < rt_1$eff_Rt_general))

})


test_that("N_tots stay constant with vaccination and no waning immunity", {
  ## waning_rate default is 0
  set.seed(1)
  vaccine_schedule <- test_vaccine_schedule(500000, "london")
  p <- lancelot_parameters(0, "london",
                           rel_susceptibility = c(1, 0.5, 0.1),
                           rel_p_sympt = c(1, 1, 1),
                           rel_p_hosp_if_sympt = c(1, 1, 1),
                           rel_p_death = c(1, 1, 1),
                           vaccine_progression_rate = c(0, 0, 0.01),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L)

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()
  y0 <- lancelot_initial(info, 1, p)
  mod$update_state(state = y0)
  y <- mod$transform_variables(drop(mod$simulate(seq(0, 400, by = 4))))

  expect_true(all(y$N_tot - mod$transform_variables(y0)$N_tot == 0))
  expect_true(all(y$N_tot_sero_1 -
                    mod$transform_variables(y0)$N_tot_sero_1 == 0))
  expect_true(all(y$N_tot_sero_2 -
                    mod$transform_variables(y0)$N_tot_sero_2 == 0))
  expect_true(all(y$N_tot_PCR - mod$transform_variables(y0)$N_tot_PCR == 0))
  expect_true(all(colSums(y$N_tot) - y$N_tot_sero_1 == 0))
  expect_true(all(colSums(y$N_tot) - y$N_tot_sero_2 == 0))
  expect_true(all(colSums(y$N_tot) - y$N_tot_PCR == 0))
})


test_that("N_tot stays constant with vaccination and waning immunity, while
          sero and PCR N_tots are non-decreasing", {
  set.seed(1)
  vaccine_schedule <- test_vaccine_schedule(500000, "london")
  p <- lancelot_parameters(0, "london", waning_rate = 1 / 20,
                           rel_susceptibility = c(1, 0.5, 0.1),
                           rel_p_sympt = c(1, 1, 1),
                           rel_p_hosp_if_sympt = c(1, 1, 1),
                           rel_p_death = c(1, 1, 1),
                           vaccine_progression_rate = c(0, 0, 0.01),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L)

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()
  y0 <- lancelot_initial(info, 1, p)
  mod$update_state(state = y0)
  y <- mod$transform_variables(drop(mod$simulate(seq(0, 400, by = 4))))

  expect_true(all(y$N_tot - mod$transform_variables(y0)$N_tot == 0))
  expect_true(all(diff(y$N_tot_sero_1) >= 0))
  expect_true(all(diff(y$N_tot_sero_2) >= 0))
  expect_true(all(diff(y$N_tot_PCR) >= 0))
  expect_true(all(colSums(y$N_tot) <= y$N_tot_sero_1))
  expect_true(all(colSums(y$N_tot) <= y$N_tot_sero_2))
  expect_true(all(colSums(y$N_tot) <= y$N_tot_PCR))
})


test_that("N_tots are constant with vaccination and k > 1, and without waning
          immunity", {
  ## waning_rate default is 0, setting to a non-zero value so that this test
  ## passes with waning immunity
  set.seed(1)
  vaccine_schedule <- test_vaccine_schedule(500000, "london")
  p <- lancelot_parameters(0, "london",
                           rel_susceptibility = c(1, 0.5, 0.1),
                           rel_p_sympt = c(1, 1, 1),
                           rel_p_hosp_if_sympt = c(1, 1, 1),
                           rel_p_death = c(1, 1, 1),
                           vaccine_progression_rate = c(0, 0, 0.01),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L)

  p[grep("k_", names(p))] <- 2

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()
  y0 <- lancelot_initial(info, 1, p)
  mod$update_state(state = y0)
  y <- mod$transform_variables(drop(mod$simulate(seq(0, 400, by = 4))))

  expect_true(all(y$N_tot - mod$transform_variables(y0)$N_tot == 0))
  expect_true(all(y$N_tot_sero_1 -
                    mod$transform_variables(y0)$N_tot_sero_1 == 0))
  expect_true(all(y$N_tot_sero_2 -
                    mod$transform_variables(y0)$N_tot_sero_2 == 0))
  expect_true(all(y$N_tot_PCR - mod$transform_variables(y0)$N_tot_PCR == 0))
  expect_true(all(colSums(y$N_tot) - y$N_tot_sero_1 == 0))
  expect_true(all(colSums(y$N_tot) - y$N_tot_sero_2 == 0))
  expect_true(all(colSums(y$N_tot) - y$N_tot_PCR == 0))
})


test_that("N_tot stays constant with vaccination and k > 1, and with waning
          immunity, while sero and PCR N_tots are non-decreasing", {
  set.seed(1)
  vaccine_schedule <- test_vaccine_schedule(500000, "london")
  p <- lancelot_parameters(0, "london", waning_rate = 1 / 20,
                           rel_susceptibility = c(1, 0.5, 0.1),
                           rel_p_sympt = c(1, 1, 1),
                           rel_p_hosp_if_sympt = c(1, 1, 1),
                           rel_p_death = c(1, 1, 1),
                           vaccine_progression_rate = c(0, 0, 0.01),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L)

  p[grep("k_", names(p))] <- 2

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()
  y0 <- lancelot_initial(info, 1, p)
  mod$update_state(state = y0)
  y <- mod$transform_variables(drop(mod$simulate(seq(0, 400, by = 4))))

  expect_true(all(y$N_tot - mod$transform_variables(y0)$N_tot == 0))
  expect_true(all(diff(y$N_tot_sero_1) >= 0))
  expect_true(all(diff(y$N_tot_sero_2) >= 0))
  expect_true(all(diff(y$N_tot_PCR) >= 0))
  expect_true(all(colSums(y$N_tot) <= y$N_tot_sero_1))
  expect_true(all(colSums(y$N_tot) <= y$N_tot_sero_2))
  expect_true(all(colSums(y$N_tot) <= y$N_tot_PCR))
})

test_that("N_tots stay constant with high rates of vaccination and without
          waning immunity", {
  ## waning_rate default is 0
  set.seed(1)
  ## TODO: set up a more specific set of tests to test the combined moves
  ## whereby in a single times step an individual progresses to next clinical
  ## stage and progresses to the next vaccination stage
  vaccine_schedule <- test_vaccine_schedule(1000000, "london")
  p <- lancelot_parameters(0, "london",
                           rel_susceptibility = c(1, 0.5, 0.1),
                           rel_p_sympt = c(1, 1, 1),
                           rel_p_hosp_if_sympt = c(1, 1, 1),
                           rel_p_death = c(1, 1, 1),
                           vaccine_progression_rate = c(0, 0, 50),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L)

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()
  y0 <- lancelot_initial(info, 1, p)
  mod$update_state(state = y0)
  y <- mod$transform_variables(drop(mod$simulate(seq(0, 400, by = 4))))

  expect_true(all(y$N_tot - mod$transform_variables(y0)$N_tot == 0))
  expect_true(all(y$N_tot_sero_1 -
                    mod$transform_variables(y0)$N_tot_sero_1 == 0))
  expect_true(all(y$N_tot_sero_2 -
                    mod$transform_variables(y0)$N_tot_sero_2 == 0))
  expect_true(all(y$N_tot_PCR - mod$transform_variables(y0)$N_tot_PCR == 0))
  expect_true(all(colSums(y$N_tot) - y$N_tot_sero_1 == 0))
  expect_true(all(colSums(y$N_tot) - y$N_tot_sero_2 == 0))
  expect_true(all(colSums(y$N_tot) - y$N_tot_PCR == 0))
})

test_that(
  "N_tot is constant with high rates of vaccination and waning immunity, while
  sero and PCR N_tots are non-decreasing", {
  ## waning_rate default is 0
  set.seed(1)
  ## TODO: set up a more specific set of tests to test the combined moves
  ## whereby in a single times step an individual progresses to next clinical
  ## stage and progresses to the next vaccination stage
  vaccine_schedule <- test_vaccine_schedule(1000000, "london")
  p <- lancelot_parameters(0, "london", waning_rate = 1 / 20,
                           rel_susceptibility = c(1, 0.5, 0.1),
                           rel_p_sympt = c(1, 1, 1),
                           rel_p_hosp_if_sympt = c(1, 1, 1),
                           rel_p_death = c(1, 1, 1),
                           vaccine_progression_rate = c(0, 0, 50),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L)

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()
  y0 <- lancelot_initial(info, 1, p)
  mod$update_state(state = y0)
  y <- mod$transform_variables(drop(mod$simulate(seq(0, 400, by = 4))))

  expect_true(all(y$N_tot - mod$transform_variables(y0)$N_tot == 0))
  expect_true(all(diff(y$N_tot_sero_1) >= 0))
  expect_true(all(diff(y$N_tot_sero_2) >= 0))
  expect_true(all(diff(y$N_tot_PCR) >= 0))
  expect_true(all(colSums(y$N_tot) <= y$N_tot_sero_1))
  expect_true(all(colSums(y$N_tot) <= y$N_tot_sero_2))
  expect_true(all(colSums(y$N_tot) <= y$N_tot_PCR))
})

test_that("Outputed vaccination numbers make sense", {
  vaccine_schedule <- test_vaccine_schedule(1000, "london")
  p <- lancelot_parameters(0, "london", waning_rate = 1 / 20,
                           rel_susceptibility = c(1, 0.5, 0.1),
                           rel_p_sympt = c(1, 1, 1),
                           rel_p_hosp_if_sympt = c(1, 1, 1),
                           rel_p_death = c(1, 1, 1),
                           vaccine_progression_rate = c(0, 0, 0.01),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L)

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()
  y0 <- lancelot_initial(info, 1, p)
  mod$update_state(state = y0)
  y <- mod$transform_variables(drop(mod$simulate(seq(0, 400, by = 4))))

  ## check outputed objects have correct dimension
  expect_equal(dim(y$cum_n_S_vaccinated), c(19, 3, 101))
  expect_equal(dim(y$cum_n_E_vaccinated), c(19, 3, 101))
  expect_equal(dim(y$cum_n_I_A_vaccinated), c(19, 3, 101))
  expect_equal(dim(y$cum_n_I_P_vaccinated), c(19, 3, 101))
  expect_equal(dim(y$cum_n_R_vaccinated), c(19, 3, 101))

  ## check cumulative stuff is increasing objects have correct dimension

  expect_true(all(apply(y$cum_n_S_vaccinated, c(1, 2), diff) >= 0))
  expect_true(all(apply(y$cum_n_E_vaccinated, c(1, 2), diff) >= 0))
  expect_true(all(apply(y$cum_n_I_A_vaccinated, c(1, 2), diff) >= 0))
  expect_true(all(apply(y$cum_n_I_P_vaccinated, c(1, 2), diff) >= 0))
  expect_true(all(apply(y$cum_n_R_vaccinated, c(1, 2), diff) >= 0))

})

test_that("Outputed S vaccination numbers are what we expect", {
  region <- "london"
  vaccine_schedule <- test_vaccine_schedule(daily_doses = Inf,
                                            region = region,
                                            mean_days_between_doses = 1000,
                                            uptake = c(rep(0, 3), rep(1, 16)))
  p <- lancelot_parameters(0, region, waning_rate = 1 / 20,
                           rel_susceptibility = c(1, 0.5),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           vaccine_progression_rate = c(0, 0),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L)

  ## stop progression in I_A to avoid moves from I_A to R for initial infectives
  p$gamma_A_step <- 0

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()
  y0 <- lancelot_initial(info, 1, p)
  mod$update_state(state = y0)
  y <- mod$transform_variables(drop(mod$simulate(seq(0, 400, by = 4))))

  i <- 4:lancelot_n_groups()

  ## there are candidates in S for vaccination
  expect_true(all(y$S[, 1, 1] > 0))
  ## every initial susceptible should be vaccinated within first day
  expect_approx_equal(y$cum_n_S_vaccinated[i, 1, 2], y$S[i, 1, 1])
  ## same for the 10 initially seeded cases
  expect_approx_equal(y$cum_n_I_A_vaccinated[i, , 2], y$I_A[i, , , , 1])

  ## Noone in the first 3 groups vaccinated:
  expect_true(all(y$cum_n_S_vaccinated[1:3, 1, ] == 0))
})


test_that("Outputed E vaccination numbers are what we expect", {
  region <- "london"
  vaccine_schedule <- test_vaccine_schedule(daily_doses = Inf,
                                            region = region,
                                            mean_days_between_doses = 1000,
                                            uptake = 1)
  p <- lancelot_parameters(0, region, waning_rate = 1 / 20,
                           rel_susceptibility = c(1, 0.5),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           vaccine_progression_rate = c(0, 0),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L)

  ## stop progression after E to avoid moves from E to I_A
  p$gamma_E_step <- 0
  ## stop progression in I_A to avoid moves from I_A to R for initial infectives
  p$gamma_A_step <- 0

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  ## empty S ans fill in E initially
  index_E <- array(info$index$E, info$dim$E)
  index_S <- array(info$index$S, info$dim$S)
  state[index_E[, , 1, ]] <- round(state[index_S] / 2)
  state[index_E[, , 2, ]] <- round(state[index_S] / 2)
  state[index_S] <- 0

  mod$update_state(state = state)
  y <- mod$transform_variables(drop(mod$simulate(seq(0, 400, by = 4))))

  i <- 4:lancelot_n_groups()
  ## there are candidates in E for vaccination
  expect_true(all(y$E[i, , , 1, 1] > 0))

  ## every initial exposed should be vaccinated within first day
  expect_approx_equal(y$cum_n_E_vaccinated[i, , 2],
                      apply(y$E[i, , , , 1], c(1, 3), sum),
                      rel_tol = 0.15)

  ## same for the 10 initially seeded cases
  expect_equal(y$cum_n_I_A_vaccinated[i, , 2], y$I_A[i, , , , 1])

})


test_that("Outputed I_A vaccination numbers are what we expect", {
  region <- "london"
  vaccine_schedule <- test_vaccine_schedule(daily_doses = Inf,
                                            region = region,
                                            mean_days_between_doses = 1000,
                                            uptake = 1)
  p <- lancelot_parameters(0, region, waning_rate = 1 / 20,
                           rel_susceptibility = c(1, 0.5),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           vaccine_progression_rate = c(0, 0),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L)

  ## stop progression after I_A to avoid moves from I_A to R
  p$gamma_A_step <- 0

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  ## move people from S to I_A initially
  index_I_A <- array(info$index$I_A, info$dim$I_A)
  index_S <- array(info$index$S, info$dim$S)
  state[index_I_A[, 1, 1, ]] <- state[index_S]
  state[index_S] <- 0

  mod$update_state(state = state)
  y <- mod$transform_variables(drop(mod$simulate(seq(0, 400, by = 4))))

  i <- 4:lancelot_n_groups()
  ## there are candidates in I_A for vaccination
  expect_true(all(y$I_A[i, , 1, 1, 1] > 0))
  ## every initial I_A should be vaccinated within first day
  expect_approx_equal(y$cum_n_I_A_vaccinated[i, , 2], y$I_A[i, , , , 1])

})


test_that("Outputed I_P vaccination numbers are what we expect", {
  region <- "london"
  vaccine_schedule <- test_vaccine_schedule(daily_doses = Inf,
                                            region = region,
                                            mean_days_between_doses = 1000,
                                            uptake = 1)
  p <- lancelot_parameters(0, region, waning_rate = 1 / 20,
                           rel_susceptibility = c(1, 0.5),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           vaccine_progression_rate = c(0, 0),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L)

  ## stop progression after I_A/I_P to avoid moves out of I_A/I_P
  p$gamma_A_step <- 0
  p$gamma_P_step <- 0

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  ## move people from S to I_P initially
  index_I_P <- array(info$index$I_P, info$dim$I_P)
  index_S <- array(info$index$S, info$dim$S)
  state[index_I_P[, 1, , ]] <- state[index_S]
  state[index_S] <- 0

  mod$update_state(state = state)
  y <- mod$transform_variables(drop(mod$simulate(seq(0, 400, by = 4))))

  i <- 4:lancelot_n_groups()
  ## there are candidates in I_P for vaccination
  expect_true(all(y$I_P[i, , 1, 1, 1] > 0))
  ## every initial I_P should be vaccinated within first day
  expect_approx_equal(y$cum_n_I_P_vaccinated[i, , 2], y$I_P[i, , , , 1])
  ## same for the 10 initially seeded cases
  expect_equal(y$cum_n_I_A_vaccinated[i, , 2], y$I_A[i, , , , 1])
})


test_that("Outputed R vaccination numbers are what we expect", {
  region <- "london"
  vaccine_schedule <- test_vaccine_schedule(daily_doses = Inf,
                                            region = region,
                                            mean_days_between_doses = 1000,
                                            uptake = 1)
  p <- lancelot_parameters(0, region,
                           waning_rate = 0, # to avoid diagonal moves out of R
                           rel_susceptibility = c(1, 0.5),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           vaccine_progression_rate = c(0, 0),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L)

  ## stop progression after I_A to avoid diagonal moves from I_A to R
  p$gamma_A_step <- 0

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  ## empty S ans fill in R initially
  index_R <- array(info$index$R, info$dim$R)
  index_S <- array(info$index$S, info$dim$S)
  state[index_R[, , ]] <- state[index_S]
  state[index_S] <- 0

  mod$update_state(state = state)
  y <- mod$transform_variables(drop(mod$simulate(seq(0, 400, by = 4))))

  i <- 4:lancelot_n_groups()
  ## there are candidates in R for vaccination
  expect_true(all(y$R[i, , 1, 1] > 0))
  ## every initial recovered should be vaccinated within first day
  expect_approx_equal(y$cum_n_R_vaccinated[i, , 2], y$R[i, , , 1])
  ## same for the 10 initially seeded cases
  expect_equal(y$cum_n_I_A_vaccinated[i, , 2], y$I_A[i, , , , 1])
})


test_that("check_rel_param rejects out of bounds errors", {
  expect_error(
    check_rel_param(NULL, "rel_param"),
    "At least one value required for rel_param")

  expect_error(
    check_rel_param(array(c(0.9, 0.8), c(1, 1, 1)), "rel_param"),
    "First value of rel_param must be 1")

  expect_error(
    check_rel_param(array(c(0.1, 0.5, 0.5, 0.5), c(1, 4, 1)), "rel_param"),
    "First value of rel_param must be 1")
})


test_that("check_rel_param allows sensible inputs", {
  expect_silent(
    check_rel_param(array(c(1, 0.5, 0.7), c(1, 1, 3)), "rel_param"))
  expect_silent(
    check_rel_param(array(c(1, 0.7, 0.5), c(1, 1, 3)), "rel_param"))
  expect_silent(
    check_rel_param(array(1, c(1, 1, 1)), "rel_param"))
  expect_silent(
    check_rel_param(array(c(1, 1, 1), c(1, 1, 3)), "rel_param"))
  expect_silent(
    check_rel_param(array(c(1, 0), c(1, 1, 2)), "rel_param"))
  expect_silent(
    check_rel_param(array(c(1, 0, 1), c(1, 1, 3)), "rel_param"))
})


test_that("check_rel_param allows <1 probs for second infection", {
  expect_silent(
    check_rel_param(array(c(1, 1, 0.5, 0.5), c(1, 4, 1)), "rel_param"))
  expect_silent(
    check_rel_param(array(c(1, 0.5, 0.5, 0.5), c(1, 4, 1)), "rel_param")
  )
})


test_that("build_rel_param rejects wrong dimension or out of bound inputs", {
  expect_error(
    build_rel_param(
      rel_param = matrix(c(1, 0.5, 1, 0.7), nrow = 2, byrow = TRUE),
      n_strains = 1, n_vacc_classes = 2, "rel_param"),
    paste("rel_param should be a three dimensional array with dimensions:",
          "age groups, strains, vaccine classes"))
  expect_error(
    build_rel_param(
      rel_param = array(c(1, 1, 0.5, 0.7), dim = c(2, 1, 2)),
      n_strains = 1, n_vacc_classes = 2, "rel_param"),
    "rel_param should have as many rows as age groups")
  expect_error(
    build_rel_param(
      rel_param = array(rep(1, 19 * 2), dim = c(19, 1, 2)),
      n_strains = 3, n_vacc_classes = 2, "rel_param"),
    "rel_param should have as many columns as strains")
  expect_error(
    build_rel_param(
      rel_param = array(rep(1, 19 * 3), dim = c(19, 3, 1)),
      n_strains = 3, n_vacc_classes = 2, "rel_param"),
    "rel_param should have number of vaccine classes as 3rd dimension")
})


test_that("build_rel_param works as expected", {
  expect_equal(
    build_rel_param(1, n_strains = 1, n_vacc_classes = 1, "rel_param"),
    array(1, dim = c(lancelot_n_groups(), 1, 1)))
  mat <- array(rep(c(1, 0.1), each = lancelot_n_groups()),
               dim = c(lancelot_n_groups(), 1, 2))
  expect_equal(
    build_rel_param(c(1, 0.1), n_strains = 1, n_vacc_classes = 2, "rel_param"),
    mat)
  expect_equal(
    build_rel_param(mat, n_strains = 1, n_vacc_classes = 2, "rel_param"),
    mat)
  mat_rand <- array(c(rep(1, lancelot_n_groups()),
                      runif(lancelot_n_groups())),
                    dim = c(lancelot_n_groups(), 1, 2))
  expect_equal(
    build_rel_param(mat_rand, n_strains = 1, n_vacc_classes = 2, "rel_param"),
    mat_rand)
})


test_that("build_vaccine_progression_rate rejects insensible inputs", {
  expect_error(
    build_vaccine_progression_rate(vaccine_progression_rate =
                                     cbind(rep(-1, 19), rep(1, 19), rep(1, 19)),
                                   n_vacc_classes = 3),
    "'vaccine_progression_rate' must have only non-negative values")
  msg1 <- "'vaccine_progression_rate' must be either:"
  msg2 <- "a vector of length 'n_vacc_classes'"
  msg3 <- "or a matrix with 'n_groups' rows and 'n_vacc_classes' columns"
  expect_error(
    build_vaccine_progression_rate(vaccine_progression_rate = c(1, 1, 1),
                                   n_vacc_classes = 2),
    paste(msg1, msg2, msg3))
  expect_error(
    build_vaccine_progression_rate(vaccine_progression_rate = c(1, 1, -1),
                                   n_vacc_classes = 3),
    "'vaccine_progression_rate' must have only non-negative values")
  expect_error(
    build_vaccine_progression_rate(vaccine_progression_rate = matrix(1, 19, 5),
                                   n_vacc_classes = 3),
    "'vaccine_progression_rate' must have 'n_vacc_classes' columns")
  expect_error(
    build_vaccine_progression_rate(vaccine_progression_rate = matrix(1, 9, 3),
                                   n_vacc_classes = 3),
    "'vaccine_progression_rate' must have as many rows as age groups")
  ntot <- rep(1000, 19)
  expect_error(
    lancelot_parameters_vaccination(
      ntot,
      rel_susceptibility = c(1, 1, 1),
      vaccine_progression_rate = c(1, 1, 1)),
    "Column 1 of 'vaccine_progression_rate' must be zero (dose 1)",
    fixed = TRUE)
  expect_error(
    lancelot_parameters_vaccination(
      ntot,
      rel_susceptibility = c(1, 1, 1),
      vaccine_progression_rate = matrix(c(1, 1, 1), 19, 3)),
    "Column 1 of 'vaccine_progression_rate' must be zero (dose 1)",
    fixed = TRUE)
  expect_error(
    lancelot_parameters_vaccination(
      ntot,
      rel_susceptibility = 1,
      vaccine_progression_rate = 1),
    "Column 1 of 'vaccine_progression_rate' must be zero (dose 1)",
    fixed = TRUE)

  schedule <- vaccine_schedule(date = 1L,
                               doses = array(0, c(19, 2, 5)))
  dt <- 1 / 4
  expect_error(
    lancelot_parameters_vaccination(
      ntot,
      dt,
      rel_susceptibility = c(1, 1, 1),
      vaccine_progression_rate = c(0, 1, 1),
      vaccine_index_dose2 = 2,
      vaccine_schedule = schedule),
    "Column 2 of 'vaccine_progression_rate' must be zero (dose 2)",
    fixed = TRUE)
  expect_error(
    lancelot_parameters_vaccination(
      ntot,
      dt,
      rel_susceptibility = c(1, 1, 1, 1),
      vaccine_progression_rate = c(0, 1, 1, 1),
      vaccine_index_dose2 = 3,
      vaccine_schedule = schedule),
    "Column 3 of 'vaccine_progression_rate' must be zero (dose 2)",
    fixed = TRUE)

  expect_error(
    lancelot_parameters_vaccination(
      ntot,
      dt,
      rel_susceptibility = c(1, 1, 1, 1),
      vaccine_progression_rate = c(0, 1, 0, 1),
      vaccine_index_dose2 = 3,
      vaccine_index_booster = 4,
      vaccine_schedule = schedule),
    "'n_doses' must be 3 as boosters are used",
    fixed = TRUE)

  schedule <- vaccine_schedule(date = 1L,
                               doses = array(0, c(19, 3, 5)), 3)
  expect_error(
    lancelot_parameters_vaccination(
      ntot,
      dt,
      rel_susceptibility = c(1, 1, 1, 1),
      vaccine_progression_rate = c(0, 1, 0, 1),
      n_doses = 3,
      vaccine_index_dose2 = 3,
      vaccine_schedule = schedule),
    "'n_doses' must be 2 as boosters not used",
    fixed = TRUE)

  expect_error(
    lancelot_parameters_vaccination(
      ntot,
      dt,
      rel_susceptibility = c(1, 1, 1, 1),
      vaccine_progression_rate = c(0, 1, 0, 1),
      n_doses = 3,
      vaccine_index_booster = 10,
      vaccine_index_dose2 = 3,
      vaccine_schedule = schedule),
    "Invalid value for 'vaccine_index_booster'",
    fixed = TRUE)
})


test_that("build_vaccine_progression_rate allows sensible inputs and works", {
  expect_silent(
    build_vaccine_progression_rate(vaccine_progression_rate = 0,
                                   n_vacc_classes = 1,
                                   index_dose = c(1, 1)))
  expect_equal(
    build_vaccine_progression_rate(vaccine_progression_rate = c(0, 1),
                                   n_vacc_classes = 2,
                                   index_dose = c(1, 1)),
    cbind(rep(0, 19), rep(1, 19)))
  expect_silent(
    build_vaccine_progression_rate(vaccine_progression_rate = matrix(0, 19, 3),
                                   n_vacc_classes = 3,
                                   index_dose = c(1, 1)))
  expect_silent(
    build_vaccine_progression_rate(vaccine_progression_rate = NULL,
                                   n_vacc_classes = 3,
                                   index_dose = c(1, 1)))
  expect_equal(
    build_vaccine_progression_rate(vaccine_progression_rate = NULL,
                                   n_vacc_classes = 3,
                                   index_dose = c(1, 1)),
    matrix(0, 19, 3))
})


test_that("build_waning_rate works as expected", {
  expect_error(
    build_waning_rate(NULL),
    "At least one value required for 'waning_rate'")
  expect_error(
    build_waning_rate(-1),
    "'waning_rate' must have only non-negative values",
    fixed = TRUE)
  expect_error(
    build_waning_rate(rep(0.5, 2)),
    "'waning_rate' should have as many elements as age groups")
  expect_equal(
    build_waning_rate(0),
    rep(0, 19))
  expect_equal(
    build_waning_rate(0.5),
    rep(0.5, 19))
  expect_equal(
    build_waning_rate(rep(0.5, 19)),
    rep(0.5, 19))
})


## Heading towards real-life use, let's vaccinate people at a rate of
## 5k/day. This does not run an epidemic beforehand though, and we'll
## use a "null" vaccine for now.
test_that("run sensible vaccination schedule, catchup = 0", {
  region <- "east_of_england"
  uptake <- c(rep(0, 3), rep(1, 16))
  daily_doses <- rep(50000, 120)
  n <- vaccine_priority_population(region, uptake,
                                   prop_hcw = rep(0, 19),
                                   prop_very_vulnerable = rep(0, 19),
                                   prop_underlying_condition = rep(0, 19))
  vaccine_schedule <- vaccine_schedule_future(0, daily_doses, 200, n)
  expect_equal(sum(vaccine_schedule$doses[, 2, ]), 0)
  expect_equal(sum(vaccine_schedule$doses[1:3, , ]), 0)

  p <- lancelot_parameters(0, "east_of_england",
                           rel_susceptibility = c(1, 1),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L,
                           vaccine_catchup_fraction = 0)

  ## Let's go:
  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)
  ## Remove seed, so that we have no infection process here:
  ## 10 here because initial_seed_size = 10
  state[state == 10] <- 0

  mod$update_state(state = state)
  mod$set_index(integer(0))

  keep <- c("cum_n_S_vaccinated",
            "cum_n_E_vaccinated",
            "cum_n_I_A_vaccinated",
            "cum_n_I_P_vaccinated",
            "cum_n_R_vaccinated")
  index <- unlist(lapply(info$index[keep], "[", 1:19), FALSE, FALSE)

  mod$set_index(index)

  y <- mod$simulate(seq(0, 380, by = 4)[-1])
  s <- array(y, c(19, 5, dim(y)[3]))

  ## Never vaccinate any young person:
  expect_true(all(s[1:3, , ] == 0))

  ## Sum over compartments
  cum_n_vaccinated <- t(apply(s, c(1, 3), sum))
  n_vaccinated <- diff(cum_n_vaccinated)

  ## You can visualise the vaccination process here:
  ## > matplot(m, type = "l", lty = 1)

  tot <- rowSums(n_vaccinated)
  expect_true(all(tot >= 48000 & tot < 51000))

  ## Vaccinate all the CHW/CHR first, then down the priority
  ## groups. This is easy to check visually but harder to describe:
  priority <- list(18:19, 17, 16, 15, 14, 13, 12, 11,
                   9:10, 7:8, 1:6)
  i <- lapply(priority, function(p)
    range(c(apply((n_vaccinated > 5000)[, p, drop = FALSE], 2, which))))
  for (j in seq_along(i)) {
    if (j > 2) {
      ## using <= as if many doses available each day you may vaccinate
      ## several priority groups in the same day
      expect_true(max(unlist(i[seq_len(j - 2)])) <= i[[j]][[1]])
    }
    if (j > 1) {
      expect_true(all(i[[j - 1]][[1]] <= i[[j]][[1]]))
    }
  }
})


test_that("run sensible vaccination schedule, catchup = 1", {
  region <- "east_of_england"
  uptake <- c(rep(0, 3), rep(1, 16))
  daily_doses <- rep(50000, 120)
  n <- vaccine_priority_population(region, uptake,
                                   prop_hcw = rep(0, 19),
                                   prop_very_vulnerable = rep(0, 19),
                                   prop_underlying_condition = rep(0, 19))
  vaccine_schedule <- vaccine_schedule_future(0, daily_doses, 200, n)
  expect_equal(sum(vaccine_schedule$doses[, 2, ]), 0)
  expect_equal(sum(vaccine_schedule$doses[1:3, , ]), 0)

  p <- lancelot_parameters(0, "east_of_england",
                           rel_susceptibility = c(1, 1),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L,
                           vaccine_catchup_fraction = 1)

  ## Let's go:
  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)
  ## Remove seed, so that we have no infection process here:
  state[state == 10] <- 0

  mod$update_state(state = state)
  mod$set_index(integer(0))

  keep <- c("cum_n_S_vaccinated",
            "cum_n_E_vaccinated",
            "cum_n_I_A_vaccinated",
            "cum_n_I_P_vaccinated",
            "cum_n_R_vaccinated")
  index <- unlist(lapply(info$index[keep], "[", 1:19), FALSE, FALSE)

  mod$set_index(index)
  y <- mod$simulate(seq(0, 380, by = 4)[-1])
  s <- array(y, c(19, 5, dim(y)[3]))

  ## Never vaccinate any young person:
  expect_true(all(s[1:3, , ] == 0))

  ## Sum over compartments
  cum_n_vaccinated <- t(apply(s, c(1, 3), sum))
  n_vaccinated <- diff(cum_n_vaccinated)

  ## You can visualise the vaccination process here:
  ## > matplot(m, type = "l", lty = 1)

  tot <- rowSums(n_vaccinated)
  expect_true(all(tot >= 45000 & tot < 55000))

  ## Vaccinate all the CHW/CHR first, then down the priority
  ## groups. This is easy to check visually but harder to describe:
  priority <- list(18:19, 17, 16, 15, 14, 13, 12, 11,
                   9:10, 7:8, 1:6)
  i <- lapply(priority, function(p)
    range(c(apply((n_vaccinated > 5000)[, p, drop = FALSE], 2, which))))
  for (j in seq_along(i)) {
    if (j > 2) {
      ## using <= as if many doses available each day you may vaccinate
      ## several priority groups in the same day
      expect_true(max(unlist(i[seq_len(j - 2)])) <= i[[j]][[1]])
    }
    if (j > 1) {
      expect_true(all(i[[j - 1]][[1]] <= i[[j]][[1]]))
    }
  }
})


test_that("can add vaccination to a set of model state", {
  region <- "east_of_england"

  p_orig <- lancelot_parameters(0, region)

  vaccine_schedule <- test_vaccine_schedule(daily_doses = 5000,
                                            region = region,
                                            mean_days_between_doses = 1000,
                                            uptake = 1)

  p_vacc <- lancelot_parameters(0, region,
                                rel_susceptibility = c(1, 1),
                                rel_p_sympt = c(1, 1),
                                rel_p_hosp_if_sympt = c(1, 1),
                                rel_p_death = c(1, 1),
                                vaccine_schedule = vaccine_schedule,
                                vaccine_index_dose2 = 2L)

  mod_orig <- lancelot$new(p_orig, 0, 10, seed = 1L)
  mod_vacc <- lancelot$new(p_vacc, 0, 10, seed = 1L)
  state_orig <- mod_orig$state()
  state_orig[] <- seq_along(state_orig)

  state_vacc <- vaccine_remap_state(state_orig, mod_orig$info(),
                                    mod_vacc$info())
  expect_equal(sum(state_vacc), sum(state_orig))

  tmp_orig <- mod_orig$transform_variables(state_orig)
  tmp_vacc <- mod_vacc$transform_variables(state_vacc)
  cmp <- function(v_orig, v_vacc, name) {
    nd <- length(dim(v_orig))
    if (identical(dim(v_orig), dim(v_vacc))) {
      identical(v_orig, v_vacc)
    } else if (nd == 2) {
      identical(v_orig, v_vacc[, 1, drop = FALSE]) &&
        all(v_vacc[, -1] == 0)
    } else if (nd == 3) {
      identical(v_orig, v_vacc[, 1, , drop = FALSE]) &&
        all(v_vacc[, -1, ] == 0)
    } else if (nd == 4) {
      identical(v_orig, v_vacc[, , 1, , drop = FALSE]) &&
        all(v_vacc[, , -1, ] == 0)
    }
  }
  expect_true(all(unlist(Map(cmp, tmp_orig, tmp_vacc, names(tmp_orig)))))
})


test_that("vaccine_uptake must be the correct length", {
  expect_error(
    vaccine_priority_proportion(uptake = c(0, 0, 0)),
    "Invalid length for 'uptake', expected 1 or 19")
})


test_that("If vaccine dose 2 index provided, we need a schedule", {
  schedule <- vaccine_schedule(date = 1L,
                               doses = array(0, c(19, 2, 5)))
  dt <- 1 / 4
  ntot <- rep(1000, 19)
  expect_error(
    lancelot_parameters_vaccination(ntot, vaccine_index_dose2 = 2L),
    "'vaccine_index_dose2' set without schedule")
})


test_that("vaccine_index_dose2 must have valid value", {
  schedule <- vaccine_schedule(date = 1L,
                               doses = array(0, c(19, 2, 5)))
  dt <- 1 / 4
  ntot <- rep(1000, 19)
  expect_error(
    lancelot_parameters_vaccination(
      ntot,
      dt,
      vaccine_index_dose2 = 2L,
      vaccine_schedule = schedule),
    "Invalid value for 'vaccine_index_dose2', must be in [1, 1]",
    fixed = TRUE)

  expect_error(
    lancelot_parameters_vaccination(
      ntot,
      dt,
      rel_susceptibility = c(1, 1, 1, 1),
      vaccine_progression_rate = c(0, 1, 1, 1),
      vaccine_index_dose2 = 6L,
      vaccine_schedule = schedule),
    "Invalid value for 'vaccine_index_dose2', must be in [1, 4]",
    fixed = TRUE)
})


test_that("can upgrade model state", {
  ## This is the situation upgrading sircovid 0.7.2 -> 0.8.0 as we
  ## lack cum_n_vaccinated; that can obviously be added.

  region <- "east_of_england"

  p_orig <- lancelot_parameters(0, region)
  mod_orig <- lancelot$new(p_orig, 0, 10, seed = 1L)
  info_orig <- mod_orig$info()

  ## Elimate our index
  info_orig$index <-
    info_orig$index[names(info_orig$index) != "cum_n_vaccinated"]
  info_orig$dim <-
    info_orig$dim[names(info_orig$dim) != "cum_n_vaccinated"]
  ## Reset the index
  k <- 0L
  for (i in seq_along(info_orig$index)) {
    n <- length(info_orig$index[[i]])
    info_orig$index[[i]] <- seq_len(n) + k
    k <- k + n
  }
  info_orig$len <- k

  state_orig <- matrix(0, info_orig$len, 10)
  state_orig[] <- seq_along(state_orig)

  ## Then a new set with vaccination:
  vaccine_schedule <- test_vaccine_schedule(daily_doses = 5000,
                                            region = region,
                                            mean_days_between_doses = 1000,
                                            uptake = 1)

  p_vacc <- lancelot_parameters(0, region,
                                rel_susceptibility = c(1, 1),
                                rel_p_sympt = c(1, 1),
                                rel_p_hosp_if_sympt = c(1, 1),
                                rel_p_death = c(1, 1),
                                vaccine_schedule = vaccine_schedule,
                                vaccine_index_dose2 = 2L)

  mod_vacc <- lancelot$new(p_vacc, 0, 10, seed = 1L)
  info_vacc <- mod_vacc$info()
  state_vacc <- vaccine_remap_state(state_orig, info_orig, info_vacc)

  expect_equal(sum(state_vacc), sum(state_orig))
  expect_equal(state_vacc[info_vacc$index$cum_n_vaccinated],
               rep(0, 2 * lancelot_n_groups()))
})


test_that("Refuse to upgrade impossible model state", {
  region <- "east_of_england"

  p_orig <- lancelot_parameters(0, region)
  mod_orig <- lancelot$new(p_orig, 0, 10, seed = 1L)
  info_orig <- mod_orig$info()

  ## Elimate our index
  info_orig$index <-
    info_orig$index[names(info_orig$index) != "E"]
  info_orig$dim <-
    info_orig$dim[names(info_orig$dim) != "E"]
  ## Reset the index
  k <- 0L
  for (i in seq_along(info_orig$index)) {
    n <- length(info_orig$index[[i]])
    info_orig$index[[i]] <- seq_len(n) + k
    k <- k + n
  }
  info_orig$len <- k

  state_orig <- matrix(0, info_orig$len, 10)
  state_orig[] <- seq_along(state_orig)

  ## Then a new set with vaccination:
  vaccine_schedule <- test_vaccine_schedule(daily_doses = 5000,
                                            region = region,
                                            mean_days_between_doses = 1000,
                                            uptake = 1)

  p_vacc <- lancelot_parameters(0, region,
                                rel_susceptibility = c(1, 1),
                                rel_p_sympt = c(1, 1),
                                rel_p_hosp_if_sympt = c(1, 1),
                                rel_p_death = c(1, 1),
                                vaccine_schedule = vaccine_schedule,
                                vaccine_index_dose2 = 2L)

  mod_vacc <- lancelot$new(p_vacc, 0, 10, seed = 1L)
  info_vacc <- mod_vacc$info()
  expect_error(
    vaccine_remap_state(state_orig, info_orig, info_vacc),
    "Can't remap state (can't add variables 'E')",
    fixed = TRUE)
  expect_error(
    vaccine_remap_state(matrix(0, info_vacc$len, 10), info_vacc, info_orig),
    "Can't downgrade state (previously had variables 'E')",
    fixed = TRUE)
})


test_that("Can vaccinate given a schedule", {
  p <- lancelot_parameters(0, "england", rel_susceptibility = c(1, 1, 0),
                           beta_value = 0,
                           rel_p_sympt = c(1, 1, 1),
                           rel_p_hosp_if_sympt = c(1, 1, 1),
                           rel_p_death = c(1, 1, 1),
                           vaccine_progression_rate = c(0, 0, 0),
                           waning_rate = 1 / 20,
                           vaccine_catchup_fraction = 0)
  p$index_dose <- c(1L, 2L)
  p$index_dose_inverse <- create_index_dose_inverse(p$n_vacc_classes,
                                                    p$index_dose)

  end_date <- sircovid_date("2020-06-01")

  start_vacc_date_1 <- sircovid_date("2020-03-01")
  delay_vacc_date_2 <- 28
  ndays_vacc <- 31
  i <- seq((start_vacc_date_1 - 1) * 4 + 1, length.out = ndays_vacc * 4)
  m <- array(0, c(19, 2, (end_date + 1) * 4))
  step_doses_1 <- 10000
  step_doses_2 <- 2000
  m[, 1, i] <- step_doses_1 # first dose schedule
  m[, 2, i + delay_vacc_date_2 * 4] <- step_doses_2 # second dose schedule
  p$vaccine_dose_step <- m

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  mod$update_state(state = state)
  steps <- seq(0, end_date * 4, by = 4)
  y <- mod$transform_variables(mod$simulate(steps))

  #### check first dose schedule
  n_vacc_first_dose <- apply(y$cum_n_vaccinated[, 1, 1, ], 1, diff)

  ## check no vaccination before wanted date
  days_vacc_1 <- seq(start_vacc_date_1, start_vacc_date_1 + ndays_vacc - 1)
  expect_true(
    all(n_vacc_first_dose[seq_len(days_vacc_1[1] - 1), ] == 0))

  ## check that in all groups but 18:19
  ## (which are small and therefore get vaccinated faster)
  ## we get the right number of vaccinations per day in the wanted interval
  x <- n_vacc_first_dose[days_vacc_1, - (18:19)]
  expect_approx_equal(x, matrix(step_doses_1 * 4, nrow(x), ncol(x)),
                      rel_tol = 0.1)

  ## check that no vaccination after wanted date
  ## we get the right number of vaccinations per day in the wanted interval
  expect_true(
    all(n_vacc_first_dose[seq(last(days_vacc_1) + 1, end_date, 1), ] == 0))

  #### check second dose schedule
  n_vacc_second_dose <- apply(y$cum_n_vaccinated[, 2, 1, ], 1, diff)

  ## check no vaccination before wanted date
  days_vacc_2 <- seq(start_vacc_date_1 + delay_vacc_date_2,
                     start_vacc_date_1 + delay_vacc_date_2 + ndays_vacc - 1)
  expect_true(
    all(n_vacc_second_dose[seq_len(days_vacc_2[1] - 1), ] == 0))

  ## check that
  ## we get the right number of vaccinations per day in the wanted interval
  x <- n_vacc_second_dose[days_vacc_2, ]
  expect_approx_equal(x, matrix(step_doses_2 * 4, nrow(x), ncol(x)))

  ## check that no vaccination after wanted date
  ## we get the right number of vaccinations per day in the wanted interval
  expect_true(
    all(n_vacc_second_dose[seq(last(days_vacc_2) + 1, end_date, 1), ] == 0))

})


test_that("can create parameters with vaccination data", {
  region <- "london"
  uptake_by_age <- test_example_uptake()
  daily_doses <- rep(20000, 365)
  mean_days_between_doses <- 12 * 7
  n <- vaccine_priority_population(region, uptake_by_age)
  date_start_vaccination <- sircovid_date("2020-02-01")
  schedule <- vaccine_schedule_future(
    date_start_vaccination, daily_doses, mean_days_between_doses, n)

  p <- lancelot_parameters(0, region,
                           rel_susceptibility = c(1, 1, 0),
                           rel_p_sympt = c(1, 1, 1),
                           rel_p_hosp_if_sympt = c(1, 1, 1),
                           rel_p_death = c(1, 1, 1),
                           waning_rate = 1 / 20,
                           vaccine_index_dose2 = 2L,
                           vaccine_schedule = schedule)
  expect_equal(dim(p$vaccine_dose_step),
               c(19, 2, (date_start_vaccination + length(daily_doses)) * 4))
})


test_that("Can vaccinate given a schedule with given uptake", {
  region <- "london"
  p <- lancelot_parameters(0, region, rel_susceptibility = c(1, 1, 0),
                           beta_value = 0,
                           rel_p_sympt = c(1, 1, 1),
                           rel_p_hosp_if_sympt = c(1, 1, 1),
                           rel_p_death = c(1, 1, 1),
                           vaccine_progression_rate = c(0, 0, 0),
                           waning_rate = 1 / 20)
  p$index_dose <- c(1L, 2L)
  p$index_dose_inverse <- create_index_dose_inverse(p$n_vacc_classes,
                                                    p$index_dose)

  end_date <- sircovid_date("2020-06-01")

  start_vacc_date_1 <- sircovid_date("2020-03-01")
  uptake_by_age <- test_example_uptake()
  daily_doses <- seq(40000, length.out = 365, by = -50)
  mean_days_between_doses <- 12 * 7

  n <- vaccine_priority_population(region, uptake_by_age)

  vacc_schedule <- vaccine_schedule_future(
    start_vacc_date_1, daily_doses, mean_days_between_doses, n)

  p$vaccine_dose_step <- vacc_schedule$doses

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  mod$update_state(state = state)
  steps <- seq(0, end_date * 4, by = 4)
  y <- mod$transform_variables(mod$simulate(steps))

  #### check we reach the desired uptake in each group
  expect_equal(y$cum_n_vaccinated[, 1, 1, 154] / p$N_tot,
               uptake_by_age, 0.01)

})


test_that("Can catch up on uptake given previous vaccination", {
  data <- test_vaccine_data()

  region <- "london"

  p <- lancelot_parameters(sircovid_date("2021-04-10"),
                           region, rel_susceptibility = c(1, 1, 0),
                           beta_value = 0,
                           rel_p_sympt = c(1, 1, 1),
                           rel_p_hosp_if_sympt = c(1, 1, 1),
                           rel_p_death = c(1, 1, 1),
                           vaccine_progression_rate = c(0, 0, 0),
                           waning_rate = 1 / 20)

  uptake_by_age <- test_example_uptake()
  n <- vaccine_priority_population(region, uptake_by_age)
  uptake_by_age_dose <- array(uptake_by_age, c(length(uptake_by_age), 2))
  past <- vaccine_schedule_from_data(data, region, uptake_by_age_dose)

  mean_days_between_doses <- 30
  doses_future <- c(
    "2021-04-10" = 60000,
    "2021-04-20" = 70000,
    "2021-04-30" = 90000)
  end_date <- "2021-08-01"

  first_doses_already_given <- rowSums(past$doses[, 1, ])
  past_uptake <- first_doses_already_given / p$N_tot
  ## so we have vaccinated full group 19 and are currently doing group 18 or 17

  ## now increase the uptake in group 19
  uptake_by_age[19] <- 0.98
  ## recalculate n
  n <- vaccine_priority_population(region, uptake_by_age)

  vacc_schedule <- vaccine_schedule_scenario(past, doses_future, end_date,
                                             mean_days_between_doses, n)

  p$index_dose <- c(1L, 2L)
  p$index_dose_inverse <- create_index_dose_inverse(p$n_vacc_classes,
                                                    p$index_dose)
  end_date <- sircovid_date(end_date)

  p$vaccine_dose_step <- vacc_schedule$doses

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  mod$update_state(state = state)
  steps <- seq(0, end_date * 4, by = 4)
  y <- mod$transform_variables(mod$simulate(steps))

  new_uptake <- y$cum_n_vaccinated[, 1, 1, 580] / p$N_tot

  #### check we reach the desired uptake in each group including group 90
  expect_equal(new_uptake,
               uptake_by_age, 0.01)

})


test_that("Can catch up on doses not distributed", {
  region <- "london"
  end_date <- sircovid_date("2023-01-01")

  mean_days_between_doses <- 12 * 7
  doses_future <- rep(25000, end_date)

  uptake_by_age <- rep(1, 19) # complete in all groups
  n <- vaccine_priority_population(region, uptake_by_age)
  vacc_schedule <- vaccine_schedule_future(
    0, doses_future, mean_days_between_doses, n)
  p <- lancelot_parameters(0, region, rel_susceptibility = c(1, 1, 0),
                           beta_value = 0.12,
                           rel_p_sympt = c(1, 1, 1),
                           rel_p_hosp_if_sympt = c(1, 1, 1),
                           rel_p_death = c(1, 1, 1),
                           vaccine_progression_rate = c(0, 0, 0),
                           vaccine_catchup_fraction = 0,
                           vaccine_index_dose2 = 2L,
                           vaccine_schedule = vacc_schedule,
                           waning_rate = 1 / 20)


  ## set gamma_C_2 so individuals will spend long periods in a compartment where
  ## they are not a vaccination candidate
  p$gamma_C_2_step <- 1 / 200

  ## check we are going far enough in time that we should vaccinate everyone:
  expect_true(all(rowSums(vacc_schedule$doses[, 1, ]) / p$N_tot > 0.99))

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()
  state <- lancelot_initial(info, 1, p)

  mod$update_state(state = state)
  steps <- seq(0, end_date * 4, by = 4)
  y <- mod$transform_variables(mod$simulate(steps))
  uptake <- y$cum_n_vaccinated[, 1, 1, dim(y$cum_n_vaccinated)[4]] / p$N_tot

  ## check we could not reach reach the desired uptake
  expect_lt(min(uptake), 0.8)

  ### now do exactly the same with vaccine catch up fully on:
  p$vaccine_catchup_fraction <- 1.0
  mod2 <- lancelot$new(p, 0, 1, seed = 1L)
  state <- lancelot_initial(info, 1, p)
  mod2$update_state(state = state)
  y2 <- mod2$transform_variables(mod2$simulate(steps))
  uptake2 <- y2$cum_n_vaccinated[, 1, 1, dim(y2$cum_n_vaccinated)[4]] / p$N_tot

  ## check we did reach the desired uptake (100%)
  expect_gt(min(uptake2), 0.98)
})


test_that("Can catch up on doses not distributed with imperfect uptake", {
  region <- "london"
  end_date <- sircovid_date("2023-01-01")

  mean_days_between_doses <- 12 * 7
  doses_future <- rep(25000, end_date)

  uptake_by_age <- test_example_uptake()
  n <- vaccine_priority_population(region, uptake_by_age)
  vacc_schedule <- vaccine_schedule_future(
    0, doses_future, mean_days_between_doses, n)
  p <- lancelot_parameters(0, region, rel_susceptibility = c(1, 1, 0),
                           beta_value = 0.1,
                           rel_p_sympt = c(1, 1, 1),
                           rel_p_hosp_if_sympt = c(1, 1, 1),
                           rel_p_death = c(1, 1, 1),
                           vaccine_progression_rate = c(0, 0, 0),
                           vaccine_catchup_fraction = 1,
                           vaccine_index_dose2 = 2L,
                           vaccine_schedule = vacc_schedule,
                           waning_rate = 1 / 20)

  ## check we are going far enough in time that we should vaccinate everyone:
  expect_true(all(abs(
    rowSums(vacc_schedule$doses[, 1, ]) / p$N_tot - uptake_by_age) < 0.1))

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()
  state <- lancelot_initial(info, 1, p)

  mod$update_state(state = state)
  steps <- seq(0, end_date * 4, by = 4)
  y <- mod$transform_variables(mod$simulate(steps))
  uptake <- y$cum_n_vaccinated[, 1, 1, dim(y$cum_n_vaccinated)[4]] / p$N_tot

  ## check we could not reach reach the desired uptake
  expect_true(all(abs(uptake - uptake_by_age) < 0.05))
})


test_that("Collect disaggregated deaths data", {
  region <- "london"
  vaccine_schedule <- test_vaccine_schedule(daily_doses = 30000,
                                            region = region,
                                            mean_days_between_doses = 21,
                                            uptake = 0.9)
  p <- lancelot_parameters(0, region,
                           waning_rate = 0, # to avoid diagonal moves out of R
                           rel_susceptibility = c(1, 0.5),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           vaccine_progression_rate = c(0, 0),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L)

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  mod$update_state(state = state)
  t <- seq(0, 400, by = 4)
  y <- mod$transform_variables(drop(mod$simulate(t)))

  n <- length(t)
  ## Check that our cululative variables are monotonic
  expect_true(all(y$D[, , -1] - y$D[, , -n] >= 0))
  expect_true(all(y$diagnoses_admitted[, , -1] -
                    y$diagnoses_admitted[, , -n] >= 0))

  ## Reaggregating deaths gives the right number
  expect_equal(apply(y$D, 3, sum), drop(y$D_tot))

  expect_equal(apply(y$diagnoses_admitted, 3, sum),
               drop(y$cum_admit_conf + y$cum_new_conf))
})


test_that("Can add missing state variables", {
  region <- "london"
  vaccine_schedule <- test_vaccine_schedule(daily_doses = 30000,
                                            region = region,
                                            mean_days_between_doses = 21,
                                            uptake = 0.9)
  p <- lancelot_parameters(0, region,
                           waning_rate = 0, # to avoid diagonal moves out of R
                           rel_susceptibility = c(1, 0.5),
                           rel_p_sympt = c(1, 1),
                           rel_p_hosp_if_sympt = c(1, 1),
                           rel_p_death = c(1, 1),
                           vaccine_progression_rate = c(0, 0),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L)

  mod <- lancelot$new(p, 0, 10, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 10, p)

  mod$update_state(state = state)
  y <- mod$run(400)

  drop <- c("D", "diagnoses_admitted")

  info_old <- create_old_info(info, drop)
  i <- unlist(info$index[names(info_old$index)], FALSE, FALSE)
  y_old <- y[i, , drop = FALSE]

  y_new <- upgrade_state(y_old, info_old, info)

  y_cmp <- y
  y_cmp[unlist(info$index[c("D", "diagnoses_admitted")], FALSE, FALSE), ] <- 0
  expect_equal(y_new, y_cmp)

  expect_error(upgrade_state(y_old[, 1], info_old, info),
               "Expected a matrix for 'state_orig'")
  expect_error(
    upgrade_state(y_new, info, info_old),
    "Can't downgrade state (previously had variables 'diagnoses_admitted'",
    fixed = TRUE)
  expect_error(
    upgrade_state(y_old, info_old, info, "diagnoses_admitted"),
    "Can't remap state (can't add variables 'D')",
    fixed = TRUE)

  expect_error(
    upgrade_state(y_old[-5, , drop = FALSE], info_old, info),
    "Expected a matrix with [0-9]+ rows for 'state_orig'")

  info$index$N_tot <- info$index$N_tot[-6]
  expect_error(
    upgrade_state(y_old, info_old, info),
    "States are incompatible lengths for 'N_tot'")
})


test_that("Can add lag to vaccine schedule", {
  region <- "london"
  end_date <- sircovid_date("2023-01-01")

  mean_days_between_doses <- 12 * 7
  doses_future <- rep(25000, end_date)

  uptake_by_age <- rep(1, 19) # complete in all groups
  n <- vaccine_priority_population(region, uptake_by_age)
  lag_days <- 7 * 4 ## 4 weeks
  lag_groups <- 1:15 ## lag groups 1-15

  expect_error(vaccine_schedule_future(
    0, doses_future, mean_days_between_doses, n, lag_groups = lag_groups),
    "must be non-NULL")

  expect_error(vaccine_schedule_future(
    0, doses_future, mean_days_between_doses, n, lag_groups = NULL,
    lag_days = lag_days),
    "must be non-NULL")

  ## does nothing for ineligible groups
  uptake_by_age_excl_3 <- c(numeric(3), rep(1, 16))
  n_excl_3 <- vaccine_priority_population(region, uptake_by_age_excl_3)
  vacc_schedule_no_lag <- vaccine_schedule_future(
    0, doses_future, mean_days_between_doses, n_excl_3)
  vacc_schedule_lag <- vaccine_schedule_future(
    0, doses_future, mean_days_between_doses, n_excl_3, lag_groups = 1:3,
    lag_days = lag_days)

  expect_equal(vacc_schedule_no_lag, vacc_schedule_lag)


  vacc_schedule_no_lag <- vaccine_schedule_future(
    0, doses_future, mean_days_between_doses, n)

  vacc_schedule_lag <- vaccine_schedule_future(
    0, doses_future, mean_days_between_doses, n, lag_groups = lag_groups,
    lag_days = lag_days)

  ## check identical for groups without lag
  expect_equal(vacc_schedule_no_lag$doses[16:19, , ],
               vacc_schedule_lag$doses[16:19, , ])

  ## check lag as expected - have to do per group as each starts at different
  ##  times
  nc <- nlayer(vacc_schedule_no_lag$doses)
  for (i in seq_len(15)) {
    start <- which(vacc_schedule_no_lag$doses[i, 1, ] > 0)[1]
    expect_equal(vacc_schedule_no_lag$doses[i, , seq.int(start, nc - lag_days)],
                 vacc_schedule_lag$doses[i, , seq.int(start + lag_days, nc)])
    expect_equal(vacc_schedule_lag$doses[i, , seq.int(1, start + lag_days - 1)],
                 matrix(0, 2, start + lag_days - 1))
  }

  ## check all previous checks pass with lag
  vacc_schedule <- vacc_schedule_lag

  p <- lancelot_parameters(0, region, rel_susceptibility = c(1, 1, 0),
                           beta_value = 0.12,
                           rel_p_sympt = c(1, 1, 1),
                           rel_p_hosp_if_sympt = c(1, 1, 1),
                           rel_p_death = c(1, 1, 1),
                           vaccine_progression_rate = c(0, 0, 0),
                           vaccine_catchup_fraction = 0,
                           vaccine_index_dose2 = 2L,
                           vaccine_schedule = vacc_schedule,
                           waning_rate = 1 / 20)

  ## set gamma_C_2 so individuals will spend long periods in a compartment where
  ## they are not a vaccination candidate
  p$gamma_C_2_step <- 1 / 200

  ## check we are going far enough in time that we should vaccinate everyone:
  expect_true(all(rowSums(vacc_schedule$doses[, 1, ]) / p$N_tot > 0.99))

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()
  state <- lancelot_initial(info, 1, p)

  mod$update_state(state = state)
  steps <- seq(0, end_date * 4, by = 4)
  y <- mod$transform_variables(mod$simulate(steps))
  uptake <- y$cum_n_vaccinated[, 1, 1, dim(y$cum_n_vaccinated)[4]] / p$N_tot

  ## check we could not reach reach the desired uptake
  expect_lt(min(uptake), 0.8)

  ### now do exactly the same with vaccine catch up fully on:
  p$vaccine_catchup_fraction <- 1.0
  mod2 <- lancelot$new(p, 0, 1, seed = 1L)
  state <- lancelot_initial(info, 1, p)
  mod2$update_state(state = state)
  y2 <- mod2$transform_variables(mod2$simulate(steps))
  uptake2 <- y2$cum_n_vaccinated[, 1, 1, dim(y2$cum_n_vaccinated)[4]] / p$N_tot

  ## check we did reach the desired uptake (100%)
  expect_gt(min(uptake2), 0.98)
})

## Dose 1 moves you from 1->2
## Dose 2 moves you from 2->3
## Dose 3 moves you from 3->4
test_that("run sensible vaccination schedule with boosters", {
  region <- "east_of_england"
  uptake <- c(rep(0, 3), rep(1, 16))
  daily_doses <- rep(100000, 120)
  booster_daily_doses <- c(rep(0, 150), rep(20000, 50))
  np <- 3
  n <- vaccine_priority_population(region, uptake,
                                   prop_hcw = rep(0, 19),
                                   prop_very_vulnerable = rep(0, 19),
                                   prop_underlying_condition = rep(0, 19))
  vaccine_schedule <- vaccine_schedule_future(
    0, daily_doses, 14, n,
    booster_daily_doses_value = booster_daily_doses)

  expect_equal(sum(vaccine_schedule$doses[1:3, , ]), 0)
  expect_gt(sum(vaccine_schedule$doses[, 3, ]), 0)

  p <- lancelot_parameters(0, "east_of_england",
                           rel_susceptibility = c(1, 1, 1, 1),
                           rel_p_sympt = c(1, 1, 1, 1),
                           rel_p_hosp_if_sympt = c(1, 1, 1, 1),
                           rel_p_death = c(1, 1, 1, 1),
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L,
                           vaccine_index_booster = 3L,
                           vaccine_catchup_fraction = 0,
                           n_doses = 3,
                           initial_seed_size = 0)

  ## Let's go:
  mod <- lancelot$new(p, 0, np, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  mod$update_state(state = state)

  y <- mod$simulate((1:220) * 4)
  y <- mod$transform_variables(drop(y))

  ## Check that cum_n_S_vaccinated shows correct pattern with booster
  ## doses being given.
  ## Never vaccinating anyone who has already received a booster.

  expect_vector_equal(y$cum_n_S_vaccinated[, 4, , ], 0)

  ## dose 1
  ## In phase one never give any doses apart from first doses
  phase1 <- 1:14
  expect_vector_equal(y$cum_n_S_vaccinated[, 2:4, , phase1], 0)
  expect_false(all(y$cum_n_S_vaccinated[, 1, , phase1] == 0))

  ## dose 2
  ## In phase two never give any doses apart from second doses
  ##  (and perhaps first)

  phase2 <- 15:120
  expect_vector_equal(y$cum_n_S_vaccinated[, 3:4, , phase2], 0)
  expect_false(all(y$cum_n_S_vaccinated[, 2, , phase2] == 0))

  ## No doses at all in phase 3
  expect_equal(sum(y$cum_n_S_vaccinated[, , , 150]),
               sum(y$cum_n_S_vaccinated[, , , 119]))

  ## Some boosters distributed in phase 4
  phase4 <- 150:200
  expect_false(all(y$cum_n_S_vaccinated[, 3, , phase4] == 0))
})


test_that("can inflate the number of vacc classes after running with 2", {
  ## two vacc classes
  p1 <- lancelot_parameters(0, "east_of_england",
                            rel_susceptibility = c(1, 1))
  ## three vacc classes
  p2 <- lancelot_parameters(0, "east_of_england",
                            rel_susceptibility = c(1, 1, 1))

  np <- 4L
  mod1 <- lancelot$new(p1, 0, np, seed = 1L)
  initial <- lancelot_initial(mod1$info(), 10, p1)
  mod1$update_state(state = initial)
  end <- sircovid_date("2020-05-01") / p1$dt
  steps <- seq(0, end, by = 1 / p1$dt)
  y1 <- mod1$run(end)
  info1 <- mod1$info()

  mod2 <- lancelot$new(p2, 0, 1)
  info2 <- mod2$info()
  y2 <- inflate_state_vacc_classes(y1, info1, info2)

  expect_equal(dim(y2), c(info2$len, np))
  expect_equal(sum(y2), sum(y1))

  expect_equal(sort(y2[, 1], decreasing = TRUE)[seq_len(info1$len)],
               sort(y1[, 1], decreasing = TRUE))
  expect_equal(sort(y2[, 1], decreasing = TRUE)[-seq_len(info1$len)],
               rep(0, info2$len - info1$len))

  ## examples of the different types of conversions:
  z1 <- mod1$transform_variables(y1)
  z2 <- mod2$transform_variables(y2)

  ## 19 groups x 1 strain x 2 ? x 3 vacc x np particles
  expect_equal(dim(z2$E), c(19, 1, 2, 3, np))
  expect_vector_equal(z2$E[, , , 3, ], 0)
  expect_equal(z2$E[, , , 1:2, , drop = FALSE], z1$E)

  ## 19 groups x 3 vacc x np particles
  expect_equal(dim(z2$cum_n_S_vaccinated), c(19, 3, np))
  expect_vector_equal(z2$cum_n_S_vaccinated[, 3, ], 0)
  expect_equal(z2$cum_n_S_vaccinated[, 1:2, , drop = FALSE],
               z1$cum_n_S_vaccinated)

  ## 19 groups x 1 strain x 3 vacc x np particles
  expect_equal(dim(z2$R), c(19, 1, 3, np))
  expect_equal(z2$R[, , 1:2, , drop = FALSE], z1$R)
  expect_vector_equal(z2$R[, , 3, ], 0)

  expect_equal(z2$time, z1$time)

  expect_error(inflate_state_vacc_classes(1), "Expected a matrix")
  expect_error(inflate_state_vacc_classes(matrix(1), list(len = 2), 2),
               "Expected a matrix with 2 rows")
  expect_error(
    inflate_state_vacc_classes(matrix(1, 2, 2),
                               list(len = 2, index = list(a = 1)),
                               list(len = 2, index = list(b = 1))),
    "Can't inflate state")
})

test_that("modify_severity works as expected", {
  nms <- c("rel_susceptibility", "rel_p_sympt",
           "rel_p_hosp_if_sympt", "rel_infectivity", "rel_p_death")

  ve1 <- set_names(rep(list(matrix(0.2, 19, 3)), 5), nms)
  ve2 <- set_names(rep(list(matrix(0.3, 19, 3)), 5), nms)
  mod <- rep(list(set_names(rep(list(1), 5), nms)), 4)
  mod[[2]][] <- 2
  mod[[3]][] <- 6
  mod[[4]][] <- 4

  expect_vector_equal(unname(unlist(modify_severity(ve1, NULL, mod))), 0.2)

  out <- modify_severity(ve1, ve2, mod)
  expect_equal(length(out), 5)
  # age x strain x vacc
  expect_equal(rowMeans(vapply(out, dim, numeric(3))), c(19, 4, 3))

  tol <- 1e-15
  lapply(out, function(x) expect_vector_equal(x[, 1, ], 0.2, tol))
  lapply(out, function(x) expect_vector_equal(x[, 2, ], 0.6, tol))
  lapply(out, function(x) expect_vector_equal(x[, 3, ], 1.8, tol))
  lapply(out, function(x) expect_vector_equal(x[, 4, ], 0.8, tol))
})


test_that("modify_severity errors as expected", {
  nms <- c("rel_susceptibility", "rel_p_sympt",
           "rel_p_hosp_if_sympt", "rel_infectivity", "rel_p_death")

  ve1 <- set_names(rep(list(matrix(1, 19, 3)), 5), nms)
  ve2 <- set_names(rep(list(matrix(0.5, 19, 3)), 5), nms)
  names(ve1)[1] <- "a"

  expect_error(modify_severity(set_names(ve1, NULL), NULL, mod), "setequal")

  expect_error(modify_severity(ve1, ve2, mod), "names(efficacy), expected",
               fixed = TRUE)

  ve1 <- set_names(rep(list(matrix(1, 19, 3)), 5), nms)
  ve2 <- set_names(rep(list(matrix(0.5, 19, 3)), 5), nms)
  names(ve2)[1] <- "a"

  expect_error(modify_severity(ve1, ve2, mod), "names(efficacy_strain_2)",
               fixed = TRUE)

  ve1 <- set_names(rep(list(matrix(1, 18, 3)), 5), nms)
  ve2 <- set_names(rep(list(matrix(0.5, 19, 3)), 5), nms)

  expect_error(modify_severity(ve1, ve2, mod), "identical(lapply",
               fixed = TRUE)
})


test_that("can't wane or boost without second dose", {
  region <- "east_of_england"
  uptake <- c(rep(0, 3), rep(1, 16))
  daily_doses <- rep(100000, 120)
  booster_daily_doses <- c(rep(0, 150), rep(20000, 50))
  np <- 3
  n <- vaccine_priority_population(region, uptake,
                                   prop_hcw = rep(0, 19),
                                   prop_very_vulnerable = rep(0, 19),
                                   prop_underlying_condition = rep(0, 19))
  vaccine_schedule <- vaccine_schedule_future(
    0, daily_doses, Inf, n,
    booster_daily_doses_value = booster_daily_doses)

  expect_equal(sum(vaccine_schedule$doses[1:3, , ]), 0)
  expect_gt(sum(vaccine_schedule$doses[, 3, ]), 0)

  rel <- c(1, 0.9, 0.5, 0.8, 0.5)

  p <- lancelot_parameters(0, "east_of_england",
                           rel_susceptibility = rel,
                           rel_p_sympt = rel,
                           rel_p_hosp_if_sympt = rel,
                           rel_p_death = rel,
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L,
                           vaccine_index_booster = 4L,
                           vaccine_catchup_fraction = 0,
                           vaccine_progression_rate = c(0, 0, 1, 0, 0),
                           n_doses = 3,
                           initial_seed_size = 0)

  ## Let's go:
  mod <- lancelot$new(p, 0, np, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  mod$update_state(state = state)

  y <- mod$simulate((1:220) * 4)
  y <- mod$transform_variables(drop(y))

  ## Only first doses
  expect_false(all(y$cum_n_S_vaccinated[, 1, , ] == 0))
  expect_vector_equal(y$cum_n_S_vaccinated[, 2:5, , ], 0)
})

test_that("boosting and waning work as expected", {
  region <- "east_of_england"
  uptake <- c(rep(0, 3), rep(1, 16))
  daily_doses <- rep(100000, 120)
  booster_daily_doses <- c(rep(0, 150), rep(20000, 50))
  np <- 3
  n <- vaccine_priority_population(region, uptake,
                                   prop_hcw = rep(0, 19),
                                   prop_very_vulnerable = rep(0, 19),
                                   prop_underlying_condition = rep(0, 19))
  vaccine_schedule <- vaccine_schedule_future(
    0, daily_doses, 14, n,
    booster_daily_doses_value = booster_daily_doses)

  expect_equal(sum(vaccine_schedule$doses[1:3, , ]), 0)
  expect_gt(sum(vaccine_schedule$doses[, 3, ]), 0)

  rel <- c(1, 0.9, 0.5, 0.8, 0.5)

  ## Scenario 1: no-one wanes or boosts
  progress <- c(0, 0, 0, 0, 0)

  p <- lancelot_parameters(0, "east_of_england",
                           rel_susceptibility = rel,
                           rel_p_sympt = rel,
                           rel_p_hosp_if_sympt = rel,
                           rel_p_death = rel,
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L,
                           vaccine_index_booster = 4L,
                           vaccine_catchup_fraction = 0,
                           vaccine_progression_rate = progress,
                           n_doses = 3,
                           initial_seed_size = 0)

  ## Let's go:
  mod <- lancelot$new(p, 0, np, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  mod$update_state(state = state)

  y <- mod$simulate((1:220) * 4)
  y <- mod$transform_variables(drop(y))

  ## Check that no-one wanes or is boosted
  expect_vector_equal(y$cum_n_S_vaccinated[, 3:5, , ], 0)

  ## Scenario 2: instant waning then boosting
  progress <- c(0, 0, Inf, 0, 0)

  p <- lancelot_parameters(0, "east_of_england",
                           rel_susceptibility = rel,
                           rel_p_sympt = rel,
                           rel_p_hosp_if_sympt = rel,
                           rel_p_death = rel,
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L,
                           vaccine_index_booster = 4L,
                           vaccine_catchup_fraction = 0,
                           vaccine_progression_rate = progress,
                           n_doses = 3,
                           initial_seed_size = 0)
  mod <- lancelot$new(p, 0, np, seed = 1L)
  info <- mod$info()
  state <- lancelot_initial(info, 1, p)
  mod$update_state(state = state)
  y <- mod$simulate((1:220) * 4)
  y <- mod$transform_variables(drop(y))

  expect_false(all(y$cum_n_S_vaccinated[, 1, , ] == 0)) # first dose
  expect_false(all(y$cum_n_S_vaccinated[, 2, , ] == 0)) # second dose
  expect_false(all(y$cum_n_S_vaccinated[, 3, , ] == 0)) # waning
  expect_false(all(y$cum_n_S_vaccinated[, 4, , ] == 0)) # boosting
  expect_vector_equal(y$cum_n_S_vaccinated[, 5, , ], 0) # no progress

  ## Scenario 3: waning within steps but misses boosting schedule
  progress <- c(0, 0, 1 / 20, 0, 0)
  p <- lancelot_parameters(0, "east_of_england",
                           rel_susceptibility = rel,
                           rel_p_sympt = rel,
                           rel_p_hosp_if_sympt = rel,
                           rel_p_death = rel,
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L,
                           vaccine_index_booster = 4L,
                           vaccine_catchup_fraction = 0,
                           vaccine_progression_rate = progress,
                           n_doses = 3,
                           initial_seed_size = 0)
  mod <- lancelot$new(p, 0, np, seed = 1L)
  info <- mod$info()
  state <- lancelot_initial(info, 1, p)
  mod$update_state(state = state)
  y <- mod$simulate((1:150) * 4)
  y <- mod$transform_variables(drop(y))

  expect_false(all(y$cum_n_S_vaccinated[, 1, , ] == 0)) # first dose
  expect_false(all(y$cum_n_S_vaccinated[, 2, , ] == 0)) # second dose
  expect_false(all(y$cum_n_S_vaccinated[, 3, , ] == 0)) # waning
  expect_vector_equal(y$cum_n_S_vaccinated[, 4:5, , ], 0) # no boosting
})

## Dose 1 moves you from 1->2
## Dose 2 moves you from 2->3
## Waning moves you from 3->4
## Dose 3 moves you from 4->5
test_that("run sensible vaccination schedule with waning and boosters", {
  region <- "east_of_england"
  uptake <- c(rep(0, 3), rep(1, 16))
  daily_doses <- rep(100000, 120)
  booster_daily_doses <- c(rep(0, 150), rep(20000, 50))
  np <- 3
  n <- vaccine_priority_population(region, uptake,
                                   prop_hcw = rep(0, 19),
                                   prop_very_vulnerable = rep(0, 19),
                                   prop_underlying_condition = rep(0, 19))
  vaccine_schedule <- vaccine_schedule_future(
    0, daily_doses, 14, n,
    booster_daily_doses_value = booster_daily_doses)

  expect_equal(sum(vaccine_schedule$doses[1:3, , ]), 0)
  expect_gt(sum(vaccine_schedule$doses[, 3, ]), 0)

  rel <- c(1, 0.9, 0.5, 0.8, 0.5)

  p <- lancelot_parameters(0, "east_of_england",
                           rel_susceptibility = rel,
                           rel_p_sympt = rel,
                           rel_p_hosp_if_sympt = rel,
                           rel_p_death = rel,
                           vaccine_schedule = vaccine_schedule,
                           vaccine_index_dose2 = 2L,
                           vaccine_index_booster = 4L,
                           vaccine_catchup_fraction = 0,
                           vaccine_progression_rate = c(0, 0, 1 / 20, 0, 0),
                           n_doses = 3,
                           initial_seed_size = 0)

  ## Let's go:
  mod <- lancelot$new(p, 0, np, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  mod$update_state(state = state)

  set.seed(1)
  y <- mod$simulate((1:220) * 4)
  y <- mod$transform_variables(drop(y))

  ## Check that cum_n_S_vaccinated shows correct pattern with booster
  ## doses being given.
  ## Never vaccinating anyone who has boosted.
  expect_vector_equal(y$cum_n_S_vaccinated[, 5, , ], 0)

  ## dose 1
  ## In phase one never give any doses apart from first doses
  phase1 <- 1:14
  expect_vector_equal(y$cum_n_S_vaccinated[, 2:5, , phase1], 0)
  expect_false(all(y$cum_n_S_vaccinated[, 1, , phase1] == 0))

  ## dose 2
  ## In phase two never give any doses apart from second doses
  ##  (and perhaps first and waning)
  phase2 <- 15:120
  expect_vector_equal(y$cum_n_S_vaccinated[, 4:5, , phase2], 0)
  expect_false(all(y$cum_n_S_vaccinated[, 2, , phase2] == 0))

  ## Only waning in phase 3
  expect_equal(sum(y$cum_n_S_vaccinated[, c(1:2, 4:5), , 150]),
               sum(y$cum_n_S_vaccinated[, c(1:2, 4:5), , 119]))
  expect_false(sum(y$cum_n_S_vaccinated[, 3, , 150]) ==
               sum(y$cum_n_S_vaccinated[, 3, , 119]))

  ## Some boosters distributed in phase 4
  phase4 <- 150:200
  expect_false(all(y$cum_n_S_vaccinated[, 4, , phase4] == 0))
})

test_that("Can validate vaccine skip move inputs", {
  expect_error(lancelot_parameters(1, "london", vacc_skip_from = 2),
               "There are 1 vaccine classes so 'vacc_skip_from' and")

  expect_error(lancelot_parameters(1, "london", vacc_skip_to = 4,
                                   rel_susceptibility = c(1, 1, 1)),
               "There are 3 vaccine classes so 'vacc_skip_from' and")

  expect_error(lancelot_parameters(1, "london", rel_susceptibility = c(1, 1, 1),
                                   vacc_skip_progression_rate = rep(0, 19),
                                   vacc_skip_from = 3L, vacc_skip_to = 2L),
               "Require vacc_skip_to = vacc_skip_from or vacc_skip_to >=")

  expect_error(lancelot_parameters(1, "london", rel_susceptibility = c(1, 1, 1),
                                   vacc_skip_progression_rate = rep(1, 19),
                                   vacc_skip_from = 2L, vacc_skip_to = 2L),
               "Require vacc_skip_progression_rate = 0 as vacc_skip_to =")

  expect_error(lancelot_parameters(1, "london", rel_susceptibility = c(1, 1, 1),
                                   vacc_skip_progression_rate = rep(0, 19),
                                   vacc_skip_weight = 1,
                                   vacc_skip_from = 2L, vacc_skip_to = 2L),
               "Require vacc_skip_weight = 0 as vacc_skip_to =")

  expect_error(lancelot_parameters(1, "london", rel_susceptibility = c(1, 1, 1),
                                   vacc_skip_progression_rate = c(1, 1),
                                   vacc_skip_weight = 1,
                                   vacc_skip_from = 1L, vacc_skip_to = 3L),
               "'vacc_skip_progression_rate' must be a scalar or a vector")

  expect_error(lancelot_parameters(1, "london", rel_susceptibility = c(1, 1, 1),
                                   vacc_skip_from = 1L, vacc_skip_to = 3L,
                                   vacc_skip_weight = 1.4),
               "'vacc_skip_weight' must lie in")

  expect_error(lancelot_parameters(1, "london", rel_susceptibility = c(1, 1, 1),
                                   vacc_skip_from = 1L, vacc_skip_to = 3L,
                                   vacc_skip_weight = -1),
               "'vacc_skip_weight' must lie in")
})

test_that("vacc_skip_dose calculated correctly", {
  vaccine_schedule <- test_vaccine_schedule(booster_daily_doses = 10000)

  p <- lancelot_parameters(1, "london",
                           rel_susceptibility = rep(1, 5),
                           vaccine_index_dose2 = 2L,
                           vaccine_index_booster = 4L,
                           vaccine_schedule = vaccine_schedule,
                           n_doses = 3L,
                           vacc_skip_from = 3L,
                           vacc_skip_to = 5L)
  expect_equal(p$vacc_skip_dose, 3L)

  p <- lancelot_parameters(1, "london",
                           rel_susceptibility = rep(1, 5),
                           vaccine_index_dose2 = 2L,
                           vaccine_index_booster = 4L,
                           vaccine_schedule = vaccine_schedule,
                           n_doses = 3L,
                           vacc_skip_from = 2L,
                           vacc_skip_to = 4L)
  expect_equal(p$vacc_skip_dose, 0)
})


test_that("N_tots stay constant with vaccine skip moves", {
  set.seed(1)
  vaccine_schedule <- test_vaccine_schedule(booster_daily_doses = 10000)

  p <- lancelot_parameters(1, "london",
                           rel_susceptibility = rep(1, 5),
                           vaccine_index_dose2 = 2L,
                           vaccine_index_booster = 4L,
                           vaccine_schedule = vaccine_schedule,
                           vaccine_progression_rate = c(0, 0, 1 / 10, 0, 0),
                           n_doses = 3,
                           vacc_skip_from = 3L,
                           vacc_skip_to = 5L,
                           vacc_skip_weight = 1,
                           vacc_skip_progression_rate = 0)

  mod <- lancelot$new(p, 0, 1, seed = 1L)
  info <- mod$info()
  y0 <- lancelot_initial(info, 1, p)
  mod$update_state(state = y0)
  y <- mod$transform_variables(drop(mod$simulate(seq(0, 400, by = 4))))

  expect_true(all(y$N_tot - mod$transform_variables(y0)$N_tot == 0))
  expect_true(all(y$N_tot_sero_1 -
                    mod$transform_variables(y0)$N_tot_sero_1 == 0))
  expect_true(all(y$N_tot_sero_2 -
                    mod$transform_variables(y0)$N_tot_sero_2 == 0))
  expect_true(all(y$N_tot_PCR - mod$transform_variables(y0)$N_tot_PCR == 0))
  expect_true(all(colSums(y$N_tot) - y$N_tot_sero_1 == 0))
  expect_true(all(colSums(y$N_tot) - y$N_tot_sero_2 == 0))
  expect_true(all(colSums(y$N_tot) - y$N_tot_PCR == 0))
})


test_that("No vaccine skip moves when expected", {
  vaccine_schedule <- test_vaccine_schedule(booster_daily_doses = 10000)

  p <- lancelot_parameters(1, "london",
                           rel_susceptibility = rep(1, 5),
                           vaccine_index_dose2 = 2L,
                           vaccine_index_booster = 4L,
                           vaccine_schedule = vaccine_schedule,
                           vaccine_progression_rate = c(0, 0, 1 / 10, 0, 0),
                           n_doses = 3,
                           vacc_skip_from = 3L,
                           vacc_skip_to = 5L,
                           vacc_skip_weight = 0,
                           vacc_skip_progression_rate = 0)
  np <- 3L
  mod <- lancelot$new(p, 0, np, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  mod$update_state(state = state)

  set.seed(1)
  y <- mod$simulate((1:220) * 4)
  y <- mod$transform_variables(drop(y))

  ## no vaccine skip moves (boosting before waning)
  expect_vector_equal(y$cum_n_vacc_skip[, , 220], 0)
  ## but lots of people getting third doses
  expect_true(sum(y$cum_n_vaccinated[, 4, , 220]) > 1e6)
})


test_that("Vaccine skip works in all compartments", {
  vaccine_schedule <- test_vaccine_schedule(daily_doses = 0,
                                            booster_daily_doses = 10000)

  ## no vaccine_progression, no infection, no waning
  p <- lancelot_parameters(1, "london", beta_value = 0,
                           m_CHR = 0, m_CHW = 0,
                           waning_rate = 0,
                           rel_susceptibility = rep(1, 5),
                           vaccine_index_dose2 = 2L,
                           vaccine_index_booster = 4L,
                           vaccine_schedule = vaccine_schedule,
                           vaccine_progression_rate = c(0, 0, 0, 0, 0),
                           n_doses = 3,
                           vacc_skip_from = 3L,
                           vacc_skip_to = 5L,
                           vacc_skip_weight = 1,
                           vacc_skip_progression_rate = 0)

  p$gamma_E_step <- 0
  p$gamma_A_step <- 0
  p$gamma_P_step <- 0
  p$waning_rate[] <- 0

  np <- 3L
  mod <- lancelot$new(p, 0, np, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  index_S <- array(info$index$S, info$dim$S)
  index_E <- array(info$index$E, info$dim$E)
  index_I_A <- array(info$index$I_A, info$dim$I_A)
  index_I_P <- array(info$index$I_P, info$dim$I_P)
  index_R <- array(info$index$R, info$dim$R)

  state[index_S[, 3]] <- 50000
  state[index_E[, , , 3]] <- 50000
  state[index_I_A[, , , 3]] <- 50000
  state[index_I_P[, , , 3]] <- 50000
  state[index_R[, , 3]] <- 50000

  mod$update_state(state = state)

  set.seed(1)
  y <- mod$simulate(1:200 * 4)
  y <- mod$transform_variables(drop(y))

  ## cum_n_X_vacc_skip should be equal to the totals in vaccine class 5
  expect_true(any(y$cum_n_S_vacc_skip > 0))
  expect_equal(y$cum_n_S_vacc_skip,
               apply(y$S[, 5, , , drop = FALSE], c(1, 3, 4), sum))
  expect_true(any(y$cum_n_E_vacc_skip > 0))
  expect_equal(y$cum_n_E_vacc_skip,
               apply(y$E[, , , 5, , , drop = FALSE], c(1, 5, 6), sum))
  expect_true(any(y$cum_n_I_A_vacc_skip > 0))
  expect_equal(y$cum_n_I_A_vacc_skip,
               apply(y$I_A[, , , 5, , , drop = FALSE], c(1, 5, 6), sum))
  expect_true(any(y$cum_n_I_P_vacc_skip > 0))
  expect_equal(y$cum_n_I_P_vacc_skip,
               apply(y$I_P[, , , 5, , , drop = FALSE], c(1, 5, 6), sum))
  expect_true(any(y$cum_n_R_vacc_skip > 0))
  expect_equal(y$cum_n_R_vacc_skip,
               apply(y$R[, , 5, , , drop = FALSE], c(1, 4, 5), sum))
})


test_that("Everyone vaccine skips if there is no waning", {
  vaccine_schedule <- test_vaccine_schedule(booster_daily_doses = 10000)

  p <- lancelot_parameters(1, "london",
                           rel_susceptibility = rep(1, 5),
                           vaccine_index_dose2 = 2L,
                           vaccine_index_booster = 4L,
                           vaccine_schedule = vaccine_schedule,
                           vaccine_progression_rate = c(0, 0, 0, 0, 0),
                           n_doses = 3,
                           vacc_skip_from = 3L,
                           vacc_skip_to = 5L,
                           vacc_skip_weight = 1,
                           vacc_skip_progression_rate = rep(0, 19))
  np <- 3L
  mod <- lancelot$new(p, 0, np, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  index_S <- array(info$index$S, info$dim$S)
  index_E <- array(info$index$E, info$dim$E)
  index_I_A <- array(info$index$I_A, info$dim$I_A)
  index_I_P <- array(info$index$I_P, info$dim$I_P)
  index_R <- array(info$index$R, info$dim$R)

  state[index_S[, 3]] <- 50000
  state[index_E[, , , 3]] <- 50000
  state[index_I_A[, , , 3]] <- 50000
  state[index_I_P[, , , 3]] <- 50000
  state[index_R[, , 3]] <- 50000

  mod$update_state(state = state)

  set.seed(1)
  y <- mod$simulate((1:200) * 4)
  y <- mod$transform_variables(drop(y))

  ## All booster moves are via vaccine skip
  expect_true(any(y$cum_n_vacc_skip > 0))
  expect_equal(y$cum_n_vacc_skip, y$cum_n_vaccinated[, 3, , ])
  expect_equal(y$cum_n_vacc_skip, y$cum_n_vaccinated[, 4, , ])
})


test_that("Equal vaccine skip weighting leads to equal distribution", {
  vaccine_schedule <- test_vaccine_schedule(daily_doses = 0,
                                            booster_daily_doses = 10000)

  p <- lancelot_parameters(1, "london",
                           rel_susceptibility = rep(1, 5),
                           vaccine_index_dose2 = 2L,
                           vaccine_index_booster = 4L,
                           vaccine_schedule = vaccine_schedule,
                           vaccine_progression_rate = c(0, 0, 0, 0, 0),
                           n_doses = 3,
                           vacc_skip_from = 3L,
                           vacc_skip_to = 5L,
                           vacc_skip_weight = 1,
                           vacc_skip_progression_rate = 0)
  np <- 3L
  mod <- lancelot$new(p, 0, np, seed = 1L)
  info <- mod$info()

  state <- lancelot_initial(info, 1, p)

  index_S <- array(info$index$S, info$dim$S)
  index_E <- array(info$index$E, info$dim$E)
  index_I_A <- array(info$index$I_A, info$dim$I_A)
  index_I_P <- array(info$index$I_P, info$dim$I_P)
  index_R <- array(info$index$R, info$dim$R)

  state[index_S[, 3:4]] <- 50000
  state[index_E[, , , 3:4]] <- 50000
  state[index_I_A[, , , 3:4]] <- 50000
  state[index_I_P[, , , 3:4]] <- 50000
  state[index_R[, , 3:4]] <- 50000

  mod$update_state(state = state)

  set.seed(1)
  y <- mod$simulate((1:200) * 4)
  y <- mod$transform_variables(drop(y))

  ## check we can vaccine skip in each possible compartment
  expect_true(any(y$cum_n_S_vacc_skip > 0))
  expect_true(any(y$cum_n_E_vacc_skip > 0))
  expect_true(any(y$cum_n_I_A_vacc_skip > 0))
  expect_true(any(y$cum_n_I_P_vacc_skip > 0))
  expect_true(any(y$cum_n_R_vacc_skip > 0))

  ## vaccine skip moves should be around half of all the moves into booster
  expect_approx_equal(colSums(y$cum_n_S_vacc_skip[, , 200])
                      / colSums(y$cum_n_S_vaccinated[, 4, , 200]), rep(0.5, 3),
                      rel_tol = 0.1)
  expect_approx_equal(colSums(y$cum_n_E_vacc_skip[, , 200])
                      / colSums(y$cum_n_E_vaccinated[, 4, , 200]), rep(0.5, 3),
                      rel_tol = 0.1)
  expect_approx_equal(colSums(y$cum_n_I_A_vacc_skip[, , 200])
                      / colSums(y$cum_n_I_A_vaccinated[, 4, , 200]),
                      rep(0.5, 3), rel_tol = 0.1)
  expect_approx_equal(colSums(y$cum_n_I_P_vacc_skip[, , 200])
                      / colSums(y$cum_n_I_P_vaccinated[, 4, , 200]),
                      rep(0.5, 3), rel_tol = 0.1)
  expect_approx_equal(colSums(y$cum_n_R_vacc_skip[, , 200])
                      / colSums(y$cum_n_R_vaccinated[, 4, , 200]), rep(0.5, 3),
                      rel_tol = 0.1)
})


test_that("Can create vaccine eligibility vector", {
  expect_equal(
    vaccine_eligibility(12),
    c(rep(0, 2), 3 / 5, rep(1, 16)))
  expect_equal(
    vaccine_eligibility(10),
    c(rep(0, 2), rep(1, 17)))
  expect_equal(
    vaccine_eligibility(-5),
    rep(1, 19))
  expect_equal(
    vaccine_eligibility(500),
    rep(c(0, 1), c(17, 2)))
})
