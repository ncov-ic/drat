##' @useDynLib squire, .registration = TRUE
##' @importFrom odin odin
##' @importFrom dde difeq
##' @importFrom magrittr %>%
##' @importFrom rlang .data
NULL
