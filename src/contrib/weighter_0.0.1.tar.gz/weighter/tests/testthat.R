library(testthat)
library(weighter)

test_check("weighter")
