library(testthat)
library(vdiffr)
library(distcrete)
library(incidence)
library(projections)
library(outbreaks)
library(magrittr)

test_check("projections")
