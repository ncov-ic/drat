## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
lang_output <- function(x, lang) {
  cat(c(sprintf("```%s", lang), x, "```"), sep = "\n")
}
cc_output <- function(x) lang_output(x, "cc")
r_output <- function(x) lang_output(x, "r")
plain_output <- function(x) lang_output(x, "plain")

## ----odin_sir, echo = FALSE, results = "asis"---------------------------------
r_output(readLines(file.path("sir.R")))

## -----------------------------------------------------------------------------
library(odin.dust)
gen_sir <- odin.dust::odin_dust("sir.R")

## -----------------------------------------------------------------------------
sir_model <- gen_sir$new(data = list(dt = 1, 
                                     S_ini = 1000, 
                                     I_ini = 10, 
                                     beta = 0.2, 
                                     gamma = 0.1),
                         step = 1,
                         n_particles = 10L,
                         n_threads = 4L,
                         seed = 1L)

## -----------------------------------------------------------------------------
sir_model$state()

## -----------------------------------------------------------------------------
sir_model$run(10)
sir_model$run(20)

## -----------------------------------------------------------------------------
dt <- 0.25
n_particles <- 10L
sir_model$reset(data = list(dt = dt, 
                            S_ini = 2000, 
                            I_ini = 10, 
                            beta = 0.4, 
                            gamma = 0.1),
                step = 0)
sir_model$state()

## ----fig.height=5, fig.width=7------------------------------------------------
n_steps <- 200
x <- array(NA, dim = c(sir_model$info()$len, n_particles, n_steps))

for (t in seq_len(n_steps)) {
  x[ , , t] <- sir_model$run(t)
}
time <- x[1, 1, ]
x <- x[-1, , ]

par(mar = c(4.1, 5.1, 0.5, 0.5), las = 1)
cols <- c(S = "#8c8cd9", I = "#cc0044", R = "#999966")
matplot(time, t(x[1, , ]), type = "l",
         xlab = "Time", ylab = "Number of individuals",
         col = cols[["S"]], lty = 1, ylim = range(x))
matlines(time, t(x[2, , ]), col = cols[["I"]], lty = 1)
matlines(time, t(x[3, , ]), col = cols[["R"]], lty = 1)
legend("left", lwd = 1, col = cols, legend = names(cols), bty = "n")

## ----odin_age, echo = FALSE, results = "asis"---------------------------------
r_output(readLines(file.path("sirage.R")))

## -----------------------------------------------------------------------------
gen_age <- odin.dust::odin_dust("sirage.R")

## -----------------------------------------------------------------------------
data(polymod, package = "socialmixr")

## In this example we use 8 age bands of 10 years from 0-70 years old.
age.limits = seq(0, 70, 10)

## Get the contact matrix from socialmixr
contact <- socialmixr::contact_matrix(
  survey = polymod,
  countries = "United Kingdom",
  age.limits = age.limits,
  symmetric = TRUE)

## Transform the matrix to the (symetrical) transmission matrix
## rather than the contact matrix. This transmission matrix is
## weighted by the population in each age band.
transmission <- contact$matrix /
  rep(contact$demography$population, each = ncol(contact$matrix))
transmission

## ---- fig.height=3.5, fig.width=7---------------------------------------------
N_age <- length(age.limits)
n_particles <- 5L
dt <- 0.25
model <- gen_age$new(data = list(dt = dt, 
                                 S_ini = contact$demography$population,
                                 I_ini = rep(10,8), 
                                 beta = 0.2, 
                                 gamma = 0.1,
                                 m = transmission,
                                 N_age = N_age),
                     step = 1,
                     n_particles = n_particles,
                     n_threads = 1L,
                     seed = 1L)

# Define how long the model runs for, number of steps
n_steps <- 300

# Create an array to contain outputs after looping the model.
# Array contains 35 rows = Total S, I, R (3), and
# in each age compartment (24) as well as the cumulative incidence (8)
x <- array(NA, dim = c(model$info()$len, n_particles, n_steps))

# For loop to run the model iteratively
for (t in seq_len(n_steps)) {
  x[ , , t] <- model$run(t)
}
time <- x[1, 1, ]
x <- x[-1, , ]
# Plotting the trajectories
par(mfrow = c(2,4), oma=c(2,3,0,0))
for (i in 1:N_age) {
  par(mar = c(3, 4, 2, 0.5))
  cols <- c(S = "#8c8cd9", I = "#cc0044", R = "#999966")
  matplot(time, t(x[i + 3,, ]), type = "l", # Offset to access numbers in age compartment
          xlab = "", ylab = "", yaxt="none", main = paste0("Age ", contact$demography$age.group[i]),
          col = cols[["S"]], lty = 1, ylim=range(x[-1:-3,,]))
  matlines(time, t(x[i + 3 + N_age, , ]), col = cols[["I"]], lty = 1)
  matlines(time, t(x[i + 3 + 2*N_age, , ]), col = cols[["R"]], lty = 1)
  legend("right", lwd = 1, col = cols, legend = names(cols), bty = "n")
  axis(2, las =2)
}
mtext("Number of individuals", side=2,line=1, outer=T)
mtext("Time", side = 1, line = 0, outer =T)

