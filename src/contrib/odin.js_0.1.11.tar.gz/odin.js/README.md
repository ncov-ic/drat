## ~odin.js~

**NOTE**: This was the a previous standalone version of odin js support; newer support has been added directly into odin (since 1.4.0). See [the odin docs](https://mrc-ide.github.io/odin/reference/odin_js_bundle.html) to get started, and [the wodin news blog](https://reside-ic.github.io/wodin-news/) for information about a web-hosted version of this support. This package exists for historical reasons only now.
