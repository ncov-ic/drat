# sircovid 0.2.0

* Refactor the particle filter and parameter handling

# sircovid 0.1.3

* Facilitate passing the default population structure into the model

# sircovid 0.1.2

* allows for chosing a small time-step in the model, argument passed using "dt" in days

# sircovid 0.1.1

* corrects a bug in the number of people leaving the ICU compartment

# sircovid 0.1.0

* initial version of the model

