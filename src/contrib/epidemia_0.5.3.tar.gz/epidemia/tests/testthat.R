library(testthat)
library(epidemia)

test_check("epidemia")
