##' @useDynLib sircovid
##' @importFrom odin odin
##' @importFrom dde difeq
NULL


cache <- new.env()
