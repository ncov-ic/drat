# orderly: src

This directory contains a series of source directories for your reports.  Each directory must contain a file `orderly.yml`.  The directory name is important - if you change it it will be treated as a totally separate report.

(you can delete or edit this file safely)
