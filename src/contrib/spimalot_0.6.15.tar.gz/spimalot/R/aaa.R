## We might relax this later and move to direct imports, but it will
## take a while.

##' @import stats
##' @import graphics
##' @import utils
NULL
