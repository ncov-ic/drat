library(testthat)
library(spimalot)

test_check("spimalot")
