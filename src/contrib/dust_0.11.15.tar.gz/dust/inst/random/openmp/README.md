## Standalone use of dust's RNG

Configure with

```
./configure
```

which will write out a `Makefile` with the path to your copy of dust's random library, then

```
make
```

The resulting program does very little of use, but will generate a lot of random numbers if you ask it to.
