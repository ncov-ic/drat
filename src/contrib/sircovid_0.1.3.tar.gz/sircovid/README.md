## sircovid

<!-- badges: start -->
[![Build Status](https://travis-ci.org/ncov-ic/sircovid.svg?branch=master)](https://travis-ci.org/ncov-ic/sircovid)
<!-- badges: end -->


* Make changes to the model in `inst/odin`
* Run `odin::odin_package(".")` from the root directory, which will generate updated files `R/odin.R` and `src/odin.c` (along with `inst/odin/<modelname>.json`, which you can ignore)

