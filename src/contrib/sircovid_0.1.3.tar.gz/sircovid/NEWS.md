#### 0.1.3

Facilitate passing the default population structure into the model

#### 0.1.2

allows for chosing a small time-step in the model, argument passed using "dt" in days

#### 0.1.1

corrects a bug in the number of people leaving the ICU compartment

#### 0.1.0

initial version of the model

