library(testthat)
library(eigen1)

test_check("eigen1")
