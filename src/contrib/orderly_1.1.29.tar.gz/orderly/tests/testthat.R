library(testthat)
library(orderly)

test_check("orderly")
