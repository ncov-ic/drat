library(testthat)
library(sircovid2)

test_check("sircovid2")
