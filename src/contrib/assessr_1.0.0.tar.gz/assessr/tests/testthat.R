library(testthat)
library(assessr)

test_check("assessr")
