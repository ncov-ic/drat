library(testthat)
library(squire)

test_check("squire")
