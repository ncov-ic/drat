deriv(N) <- r * N * (1 - N / K)
initial(N) <- N0

N0 <- 1
K <- 100
r <- 0.5
