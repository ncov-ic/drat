##' @useDynLib squire
##' @importFrom odin odin
##' @importFrom dde difeq
##' @importFrom magrittr %>%
##' @importFrom rlang .data
NULL
