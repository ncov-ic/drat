## pkgapi

<!-- badges: start -->
[![Project Status: Concept – Minimal or no implementation has been done yet, or the repository is only intended to be a limited example, demo, or proof-of-concept.](https://www.repostatus.org/badges/latest/concept.svg)](https://www.repostatus.org/#concept)
[![Build Status](https://travis-ci.com/reside-ic/fstorr.svg?branch=master)](https://travis-ci.com/reside-ic/fstorr)
[![codecov.io](https://codecov.io/github/reside-ic/fstorr/coverage.svg?branch=master)](https://codecov.io/github/reside-ic/fstorr?branch=master)
[![CodeFactor](https://www.codefactor.io/repository/github/reside-ic/fstorr/badge)](https://www.codefactor.io/repository/github/reside-ic/fstorr)
<!-- badges: end -->

An experiment in a content-addressible global resource cache, designed for keeping track of files pulled from external webservers.

## License

MIT © Rich FitzJohn
