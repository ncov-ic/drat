library(testthat)
library(fstorr)

test_check("fstorr")
