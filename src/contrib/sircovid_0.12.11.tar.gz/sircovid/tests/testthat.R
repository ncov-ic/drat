library(testthat)
library(sircovid)

test_check("sircovid")
