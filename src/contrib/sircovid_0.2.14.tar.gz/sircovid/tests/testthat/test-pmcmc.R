context("pmcmc")



test_that("pmcmc runs without error", {
  data <- read.csv(sircovid_file("extdata/example.csv"),
                   stringsAsFactors = FALSE)
  
  cmp <- readRDS("reference_pmcmc.rds")
  
  n_mcmc <- 10
  set.seed(1)
  X <- pmcmc(
    data = data, 
    n_mcmc = n_mcmc
  )
  
  
  expect_is(X, 'list')
  expect_setequal(names(X), c('inputs', 'results', 'states', 'acceptance_rate', 'ess'))
  expect_equal(dim(X$results), c(n_mcmc + 1L, 5))
  expect_equal(dim(X$states), c(n_mcmc + 1L, 238))
  expect_equal(X, cmp)
 
 

 
 ## set likelihood to accept every time with outlandish proposals
 Y <- pmcmc(
   data = data, 
   n_mcmc = n_mcmc,
   pars_sd = list('beta' = 10, 'start_date' = 1e2), 
   log_likelihood = function(pars, ...) {
     list('log_likelihood' = 0,
          'sample_state' = rep(1, 238))
   }
 )
 expect_equal(Y$results$log_likelihood, rep(0, n_mcmc + 1L))
 # check that all proposals have been accepted
 expect_true(all(diff(Y$results$beta) != 0))
 # check that all start_dates are before data
 expect_true(max(Y$results$start_date) <= data$date[1])
 # check beta is in specified range
 expect_true(min(Y$results$beta) > 0)
 expect_true(max(Y$results$beta) < 1)
 

  
  
})

test_that("pmcmc error cases", {
  data <- read.csv(sircovid_file("extdata/example.csv"),
                   stringsAsFactors = FALSE)
  n_mcmc <- 10
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      pars_init = list(0.5,
                       as.Date("2020-02-01"))
    ),
    "pars_init must be a list of length two with names 'beta' and 'start_date'"
  )

  ## beta too low
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      pars_init = list('beta' = -1,
                       'start_date' = as.Date("2020-02-01"))
    ),
    'initial parameters are outside of specified range'
  )
  
  ## start_date too late
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      pars_init = list('beta' = -1,
                       'start_date' = as.Date(data$date[3]))
    ),
    'initial parameters are outside of specified range'
  )
  
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      model_start_date =  as.Date(data$date[1]),
      pars_init = list('beta' = 0.01,
                       'start_date' = as.Date(data$date[1])), 
      pars_min = list('beta' = 0, 'start_date' = 0)
    ),
    "'start_date' must be less than the first date in data"
  )
  
  model_params <- generate_parameters(
    transmission_model = "POLYMOD",
    progression_groups = list(E = 2, asympt = 1, mild = 1, ILI = 1, hosp = 2, ICU = 2, rec = 2),
    gammas = list(E = 1/2.5, asympt = 1/2.09, mild = 1/2.09, ILI = 1/4, hosp = 2/1, ICU = 2/5, rec = 2/5),
    hosp_transmission = 0,
    ICU_transmission = 0,
    trans_profile = 1,
    trans_increase = 1,
    dt = 0.25)
  
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      model_params = model_params,
      model_start_date =  as.Date(data$date[1]),
      pars_init = list('beta' = 0.01,
                       'start_date' = as.Date(data$date[1])), 
      pars_min = list('beta' = 0, 'start_date' = 0)
    ),
    "Set beta variation through generate_beta, not model_params"
  )
  
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      pars_init = list('beta' = -0.01,
                       'start_date' =  as.Date("2020-02-01")), 
      pars_min = list('beta' = -1 ,'start_date' = 0)
    ),
    "beta must not be negative"
  )
  
  
  # incorrect names supplied to pars_min
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      pars_min  = list(0.5, 0)
    ),
    "pars_min must be a list of length two with names 'beta' and 'start_date'"
  )
  
  # incorrect format for pars_min
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      pars_min  = c('beta' = 0.5,
                       'start_date' = 0)
    ),
    "pars_min must be a list of length two with names 'beta' and 'start_date'"
  )
  
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      pars_min  = list('beta' = 0.5,
                    'start_date' = as.Date(data$date[1]))
    ),
    "pars_min entries must be numeric"
  )
  
  # incorrect names supplied to pars_max
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      pars_max  = list(0.5, 1e3)
    ),
    "pars_max must be a list of length two with names 'beta' and 'start_date'"
  )
  
  # incorrect format for pars_max
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      pars_max  = c('beta' = 0.5,
                    'start_date' = 1e3)
    ),
    "pars_max must be a list of length two with names 'beta' and 'start_date'"
  )
  
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      pars_max  = list('beta' = 0.5,
                       'start_date' = as.Date(data$date[1]))
    ),
    "pars_max entries must be numeric"
  )
  
  
  # incorrect names supplied to pars_sd
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      pars_sd = list(0.5, 3)
    ),
    "pars_sd must be a list of length two with names 'beta' and 'start_date'"
  )
  
  # incorrect format for pars_sd
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      pars_sd  = c('beta' = 0.5,
                    'start_date' = 3)
    ),
    "pars_sd must be a list of length two with names 'beta' and 'start_date'"
  )
  
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      pars_sd  = list('beta' = 0.5,
                      'start_date' = as.Date(data$date[1]))
    ),
    "pars_sd entries must be numeric"
  )
  
  # incorrect names supplied to pars_discrete
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      pars_discrete = list(FALSE,TRUE)
    ),
    "pars_discrete must be a list of length two with names 'beta' and 'start_date'"
  )
  # incorrect format for pars_discrete
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      pars_discrete = c('beta' = FALSE, 'start_date' = TRUE)
    ),
    "pars_discrete must be a list of length two with names 'beta' and 'start_date'"
  )
  
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      pars_discrete  = list('beta' = 0.5,
                       'start_date' = as.Date(data$date[1]))
    ),
    "pars_discrete entries must be logical"
  )
  
  ### checks on supplied log prior function

  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      log_prior = function(pars) {
        dunif(pars, min = 0, max = 1e6, log = TRUE)
      }
    ),
    'log_prior must return a single numeric representing the log prior'
  )
  
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      log_prior = function(pars) {
        sum(dunif(pars, min = 0, max = 1e6))
      }
    ),
    'log_prior must be negative or zero'
  )
  
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      log_prior = function(pars) {
        sum(dunif(pars, min = 1e6-1, max = 1e6, log = TRUE))
      }
    ),
    'initial parameters are not compatible with supplied prior'
  )
  
  # checks on supplied log likelihood function
  
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      log_likelihood = function(pars) {
        dunif(pars, min = 0, max = 1e6, log = TRUE)
      }
    ),
    'log_likelihood function must be able to take unnamed arguments'
  )
  
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      log_likelihood = function(pars, ...) {
        x <- sum(dunif(pars, min = 0, max = 1e6, log = TRUE))
        list('log_likelihood' = x)
      }
    ),
    'log_likelihood function must return a list containing elements log_likelihood and sample_state'
  )
  
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      log_likelihood = function(pars, ...) {
        x <- sum(dunif(pars, min = 0, max = 1e6, log = TRUE))
        list('log_likelihood' = x, "sample_state" = x)
      }
    ),
    'sample_state must be a vector of non-negative numbers'
  )
  
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      log_likelihood = function(pars, ...) {
        x <- sum(dunif(pars, min = 0, max = 1e6, log = TRUE))
        list(x, rep(1, 236))
      }
    ),
    'log_likelihood function must return a list containing elements log_likelihood and sample_state'
  )
  
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      log_likelihood = function(pars, ...) {
        x <- dunif(pars, min = 0, max = 1e6, log = TRUE)
        list('log_likelihood'= x, 'sample_state' = rep(1, 236))
      }
    ),
    'log_likelihood must be a single numeric representing the estimated log likelihood'
  )
  
  
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      log_likelihood = function(pars, ...) {
        x <- sum(dunif(pars, min = 0, max = 1e6, log = FALSE))
        list('log_likelihood'= x, 'sample_state' = rep(1, 236))
      }
    ),
    'log_likelihood must be negative or zero'
  )
  
  expect_error(
    pmcmc(
      data = data,
      n_mcmc = n_mcmc,
      log_likelihood = function(pars, ...) {
        x <- sum(dunif(pars, min = 0, max = 1e6, log = TRUE))
        list('log_likelihood'= x, 'sample_state' = rep(-1, 236))
      }
    ),
    'sample_state must be a vector of non-negative numbers'
  )
 
  
})

test_that("reflect_proposal", {
  
  expect_equal(object = reflect_proposal(x = 6, floor = 1, cap = 5), 
              expected = 4)
  
  expect_equal(object = reflect_proposal(x = 0, floor = 1, cap = 5), 
               expected = 2)
  
  expect_equal(object = reflect_proposal(x = 10, floor = 1, cap = 5), 
               expected = 2)
  

  
  # check that the function behaves as expected when passed a vector
  n <- 10
  tmp <- data.frame(x = rnorm(n, 1), 
                    floor = runif(n))
  tmp$cap <- tmp$floor + runif(n)
  
  X <- with(tmp, reflect_proposal(x, floor, cap))
  Y <- with(tmp, mapply(FUN = reflect_proposal, 
                        x = x, 
                        floor = floor, 
                        cap = cap))
  
  expect_equal(X, Y)
  
})
