library(testthat)
library(orderly.rstudio)

test_check("orderly.rstudio")
