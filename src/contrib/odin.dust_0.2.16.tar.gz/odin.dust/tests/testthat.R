library(testthat)
library(odin.dust)

test_check("odin.dust")
