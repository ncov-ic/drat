# pika

<!-- badges: start -->
[![Travis build status](https://travis-ci.com/mrc-ide/pika.svg?branch=master)](https://travis-ci.com/mrc-ide/pika)
<!-- badges: end -->

A lightweight package for evaluating correlation between time series
