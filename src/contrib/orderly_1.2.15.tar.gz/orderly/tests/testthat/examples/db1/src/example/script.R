png("mygraph.png")
boxplot(mpg ~ cyl, dat1)
dev.off()
