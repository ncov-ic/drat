saveRDS(list(a = a, b = b, c = c),
        "results.rds")
