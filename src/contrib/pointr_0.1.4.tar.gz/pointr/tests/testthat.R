library(testthat)
library(pointr)

test_check("pointr")
