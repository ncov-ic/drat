## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  error = FALSE,
  collapse = TRUE,
  comment = "#>",
  fig.width = 7,
  fig.height = 5)
lang_output <- function(x, lang) {
  cat(c(sprintf("```%s", lang), x, "```"), sep = "\n")
}
cc_output <- function(x) lang_output(x, "cc")
r_output <- function(x) lang_output(x, "r")
plain_output <- function(x) lang_output(x, "plain")

## ----walk_code, echo = FALSE, results = "asis"--------------------------------
cc_output(readLines(dust:::dust_file("examples/walk.cpp")))

## ----walk_compile, eval = FALSE-----------------------------------------------
#  path_walk <- system.file("examples/walk.cpp", package = "dust")
#  walk <- dust::dust(path_walk, quiet = TRUE)

## ----walk_load----------------------------------------------------------------
walk <- dust::dust_example("walk")

## ----walk_object--------------------------------------------------------------
walk

## ----walk_create--------------------------------------------------------------
model <- walk$new(list(sd = 1), 0, 20)
model

## ----walk_initial_state-------------------------------------------------------
model$state()

## ----walk_run_1---------------------------------------------------------------
model$run(100)

## ----walk_state_1-------------------------------------------------------------
model$state()

## ----walk_simulate_many-------------------------------------------------------
model <- walk$new(list(sd = 1), 0, 20000)
invisible(model$run(100))
hist(model$state(), freq = FALSE, las = 1, col = "steelblue2", main = "",
     ylim = c(0., 0.04), xlab = "State")
curve(dnorm(x, 0, 10), col = "orange", add = TRUE, lwd = 2)

## ---- walk_parallel-----------------------------------------------------------
model <- walk$new(list(sd = 1), 0, 20, n_threads = 2)
model$run(100)

## ---- walk_serial-------------------------------------------------------------
model <- walk$new(list(sd = 1), 0, 20, n_threads = 1)
model$run(100)

## ----sir_code, echo = FALSE, results = "asis"---------------------------------
cc_output(readLines(dust:::dust_file("examples/sir.cpp")))

## ----sir_compile--------------------------------------------------------------
sir <- dust::dust_example("sir")

## ----sir_coef-----------------------------------------------------------------
coef(sir)

## ----sir_create---------------------------------------------------------------
model <- sir$new(list(), 0, 20)

## ----sir_info-----------------------------------------------------------------
model$info()

## ----sir_initial_state--------------------------------------------------------
model$state()

## ----sir_set_index------------------------------------------------------------
model$set_index(2L)

## ----sir_run------------------------------------------------------------------
model$run(10)
model$run(20)

## ----sir_run_named------------------------------------------------------------
model$set_index(c(I = 2L))
model$run(30)

## ----sir_state----------------------------------------------------------------
model$state()

## ----sir_state_select---------------------------------------------------------
model$state(c(S = 1L, R = 3L))

## ----sir_run_collect----------------------------------------------------------
model <- sir$new(list(), 0, 200)
model$set_index(2L)
steps <- seq(0, 600, by = 5)
state <- model$simulate(steps)

## ----sir_run_dim--------------------------------------------------------------
dim(state)

## ----sir_transform------------------------------------------------------------
traces <- t(drop(state))

## ----sir_average--------------------------------------------------------------
time <- steps / 4
matplot(time, traces, type = "l", lty = 1, col = "#00000022",
        xlab = "Time", ylab = "Number infected (I)")
lines(time, rowMeans(traces), col = "red", lwd = 2)

## ----reorder_setup------------------------------------------------------------
model <- walk$new(list(sd = 1), 0, 20)
model$run(1)

## ----reorder_index------------------------------------------------------------
index <- order(model$state())
index

## ----reorder_apply------------------------------------------------------------
model$reorder(index)
model$state()

## ----reorder_weighted_index---------------------------------------------------
p <- dnorm(model$state())
index <- sample(length(p), replace = TRUE , prob = p)
index

## ----reorder_weighted_apply---------------------------------------------------
model$reorder(index)
model$state()

## ----set_state----------------------------------------------------------------
model <- sir$new(list(), 0, 20)
model$set_state(c(1000, 1, 0, 0, 0))
model$state()

## -----------------------------------------------------------------------------
steps <- seq(0, 600, by = 5)
state <- t(drop(dust::dust_iterate(model, steps, 2L)))
time <- steps / 4
matplot(time, state, type = "l", lty = 1, col = "#00000022",
        xlab = "Time", ylab = "Number infected (I)")

## ----initial_step-------------------------------------------------------------
step0 <- sample(0:30, 20, replace = TRUE)
model <- sir$new(list(), 0, 20)
model$set_state(c(1000, 10, 0, 0, 0), step0)

## -----------------------------------------------------------------------------
model$step()

## -----------------------------------------------------------------------------
model$state()

## -----------------------------------------------------------------------------
steps <- seq(max(step0), 600, by = 5)
state <- t(drop(dust::dust_iterate(model, steps, 2L)))
time <- steps / 4
matplot(time, state, type = "l", lty = 1, col = "#00000022",
        xlab = "Time", ylab = "Number infected (I)")

## -----------------------------------------------------------------------------
I0 <- rpois(20, 10)
state0 <- rbind(1010 - I0, I0, 0, 0, 0, deparse.level = 0)
model$set_state(state0, 0L)
model$step()
model$state()

## -----------------------------------------------------------------------------
model$set_state(state0, step0)
model$step()
model$state()

## -----------------------------------------------------------------------------
model <- walk$new(list(sd = 1), 0, 200, seed = 1L)
y1 <- model$run(100)

## -----------------------------------------------------------------------------
model <- walk$new(list(sd = 2), 0, 200)
y2 <- model$run(100)

## ----pkg_setup, include = FALSE-----------------------------------------------
desc <- c(
  "Package: example",
  "Title: Example Dust in a Package",
  "Version: 0.0.1",
  "LinkingTo: cpp11, dust",
  "Authors@R: c(person('A', 'Person', role = c('aut', 'cre')",
  "                     email = 'person@example.com'))",
  "License: CC0")
ns <- "useDynLib('example', .registration = TRUE)"

path <- tempfile()
dir.create(path)
dir.create(file.path(path, "inst/dust"), FALSE, TRUE)
writeLines(desc, file.path(path, "DESCRIPTION"))
writeLines(ns, file.path(path, "NAMESPACE"))
path_ex <- system.file("examples", package = "dust", mustWork = TRUE)
file.copy(file.path(path_ex, "walk.cpp"), file.path(path, "inst/dust"))

## ----pkg_tree, echo = FALSE---------------------------------------------------
withr::with_dir(path, fs::dir_tree())

## ----pkg_desc, echo = FALSE, results = "asis"---------------------------------
plain_output(readLines(file.path(path, "DESCRIPTION")))

## ----pkg_walk, echo = FALSE, results = "asis"---------------------------------
cc_output(readLines(file.path(path, "inst/dust/walk.cpp")))

## ----pkg_generate-------------------------------------------------------------
dust::dust_package(path)

## ----pkg_tree_after, echo = FALSE---------------------------------------------
withr::with_dir(path, fs::dir_tree())

## ----pkg_walk_c, echo = FALSE, results = "asis"-------------------------------
cc_output(readLines(file.path(path, "src/walk.cpp")))

## ----pkg_dust_r, echo = FALSE, results = "asis"-------------------------------
r_output(readLines(file.path(path, "R/dust.R")))

