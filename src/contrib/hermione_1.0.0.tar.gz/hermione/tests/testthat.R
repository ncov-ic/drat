library(testthat)
library(hermione)

test_check("hermione")
